package com.example.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.spring.exception.ResourceNotFound;
import com.example.spring.model.employee;
import com.example.spring.repository.employeeRepository;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/v1")
public class employeeController {

	@Autowired
	private employeeRepository employeeRepository;
	
	@PostMapping("/employees")
	public employee addEmployee(@RequestBody employee employee) {
		return employeeRepository.save(employee);
	}
	
	@GetMapping("/employees")
	public List<employee> getAllEmployees(){
		return employeeRepository.findAll();
	}
	
	@GetMapping("/employees/{id}")
	public ResponseEntity<employee> getEmployeeById(@PathVariable Long id) {
		
		employee employee = employeeRepository.findById(id)
				.orElseThrow(()-> new ResourceNotFound("Employee not find with the Id : "+ id));
		return ResponseEntity.ok(employee);
		
	}
	
	@PutMapping("/employees/{id}")
	public ResponseEntity<employee> updateEmployee(@PathVariable Long id, @RequestBody employee employeeDetails){
		
		employee employee = employeeRepository.findById(id)
				.orElseThrow(()-> new ResourceNotFound("Employee not find with the Id : "+ id));
		
		employee.setFirstName(employeeDetails.getFirstName());
		employee.setLastName(employeeDetails.getLastName());
		employee.setEmail(employeeDetails.getEmail());
		
		employee updateEmployee = employeeRepository.save(employee);
		return ResponseEntity.ok(updateEmployee);
	}
	
	@DeleteMapping("/employees/{id}")
	public ResponseEntity<String> deleteEmployee(@PathVariable Long id){
		employee employee = employeeRepository.findById(id)
				.orElseThrow(()-> new ResourceNotFound("Employee not find with the Id : "+ id));
		
		employeeRepository.delete(employee);
		return new ResponseEntity<>("Employee deleted ", HttpStatus.OK);
		
		
	}
}