package com.exam.console;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.exam.model.Admin;
import com.exam.model.Student;
import com.spring.util.HibernateUtil;

public class Authentication {

	public static boolean validate(String username, String password) {
		
		SessionFactory sessionFactory= new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
		try {
			String hql = " FROM Admin WHERE username = :username AND password = :password ";
			List<Admin> admin = session.createQuery(hql, Admin.class).setParameter("username", username).setParameter("password",password).getResultList();
			return !admin.isEmpty();
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}finally {
			transaction.commit();
			session.close();
			sessionFactory.close();
		}
	} 
	

public static boolean validateStd(int studentId, String studentPassword) {
		
		SessionFactory sessionFactory= new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
		try {
			String hql = " FROM Student WHERE student_id = :student_id AND student_password = :student_password ";
			List<Student> student = session.createQuery(hql, Student.class).setParameter("student_id", studentId).setParameter("student_password",studentPassword).getResultList();
			return !student.isEmpty();
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}finally {
			transaction.commit();
			session.close();
			sessionFactory.close();
		}
	} 
}
