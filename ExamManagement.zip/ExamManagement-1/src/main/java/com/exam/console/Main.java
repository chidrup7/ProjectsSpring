package com.exam.console;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.exam.service.ExamService;
import com.exam.service.QuestionService;
import com.exam.service.ReportService;
import com.exam.service.StudentService;


@Component
public class Main {
	
	@Autowired
	ExamService examService;
	
	@Autowired
	QuestionService questionService;
	 
    @Autowired
    ReportService reportService;
	
	@Autowired
	StudentService studentService;
	
	public void examMain() {
		System.out.println("------Please Select Your Role ------");
		
		
		
		Scanner sc = new Scanner(System.in);
		int ch;
		
		do {
			System.out.println("1. Admin");
			System.out.println("2. Student");
			System.out.println("--------------");
			System.out.println("Enter Your Choice:");
			ch = sc.nextInt();
			System.out.println("--------------");
			switch(ch){
			case 1:
				Admin();
			break;
			case 2:
				Student();
			break;
			}
		}while(ch!=0);		
		
	}
	
	public void Admin()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("---------------------");
		System.out.println("Enter your username:");
		String username = sc.nextLine();
		System.out.println("Enter your password:");
		String password = sc.nextLine();
	
		if(Authentication.validate(username,password)) {
			System.out.println("HI");
			AdminOpt();
		}
		else {
			System.out.println("Invalid Username and Password");
		}
	}
		
	
	public void AdminOpt() {
		Scanner sc1 = new Scanner(System.in);
		int ao;
		do {
			System.out.println("-----------------------");
			System.out.println("----Admin Operations ----");
			System.out.println("--------------------------");	
			System.out.println("1. Create Exam");
			System.out.println("2. Delete Exam ");
			System.out.println("3. Update Exam");
			System.out.println("4. Get all Exam");
			System.out.println("5. Get Exam by ID");
			System.out.println("6. Add student");
			System.out.println("7. Delete student");
			System.out.println("8. Update student");
			System.out.println("9. Get All students list");
			System.out.println("10. Get Student by Student Id");
			System.out.println("11. Get Consolidated Students report card");
			System.out.println("12. Get single student report card by ID");
			System.out.println("13. Add Question in Exam");
			System.out.println("14. Update Question in Exam");
			System.out.println("15. Delete Question from exam");
			System.out.println("16. Display all question from exam");
			System.out.println("0. Exit");
			System.out.println("--------------------------");
			System.out.println("Enter Your Choice:");
			System.out.println("--------------");
			 ao = sc1.nextInt();
			
			switch(ao) {
			case 1:
				examService.addExam();
				break;
				
			case 2:
				examService.deleteExamById();
				break;
				
			case 3:
				examService.updateExam();
				break;
				
			case 4:
				examService.ListExams();
				break;
				
			case 5:
				System.out.println("Enter Exam Id:");
		        int examId = sc1.nextInt();
				examService.fetchExamById(examId);
				break;
				
			case 6:
				studentService.addStudent();
				break;
				
			case 7:
				studentService.deletebyId();
				break;
				
			case 8:
				studentService.updateStudent();
				break;
				
			case 9:
				studentService.fetchAllStudents();
				break;
				
			case 10:
				System.out.println("Enter Student Id:");
		        int studentId = sc1.nextInt();
				studentService.fetchStudentId(studentId);
				break;
				
			case 11:
				reportService.fetchAllReports();
				break;
				
			case 12:
				System.out.println("Enter Student Id:");
		        int studentId1 = sc1.nextInt();
				reportService.fetchReportByStudentId(studentId1);
				break;
				
			case 13:
				questionService.addQuestion();
				break;
				
			case 14:
				questionService.updateQuestion();
				break;
				
			case 15:
				questionService.deleteQuestionById();
				break;
				
			case 16:
				questionService.getQuestions();
				break;
			}
		}while(ao!=0);	
	}
	
	public void Student() {
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		System.out.println("---------------------");
		System.out.println("Enter your student id:");
		int studentId = sc.nextInt();
		System.out.println("Enter your password:");
		String studentPassword = sc1.nextLine();
	
		if(Authentication.validateStd(studentId,studentPassword)) {
			System.out.println("HI");
			StudentOpt();
		}
		else {
			System.out.println("Invalid UserId and Password");
		}	
		
		
	}
	
	
	public void StudentOpt()
	{ 
		Scanner sc2 = new Scanner(System.in);
		int so;
		do {
		System.out.println("---- Student Dashboard ----");
		System.out.println("1. Go For the test");
		System.out.println("2. See Your report card");
		System.out.println("0. Exit");
		System.out.println("-----------------------------");
		System.out.println("Enter Your Choice:");
		so = sc2.nextInt();
		switch (so) {
		case 1:
			reportService.startExam();
			break;
		case 2:
			System.out.println("Enter Student Id:");
	        int studentId = sc2.nextInt();
			reportService.fetchReportByStudentId(studentId);
			break;
		}
		}while(so!=0);
	}
	
}


