package com.exam.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.model.Exam;
import com.exam.model.Question;
import com.exam.repository.QuestionRepository;

@Service
public class QuestionService {
	
	@Autowired
	QuestionRepository questionRepository;
	
	@Autowired
	ExamService examService;
	
	

	public void addQuestion(){
		
		 
		
		List<Exam> exams = examService.ListExams();
        if (exams.isEmpty()) {
            System.out.println("No exams found. Create an exam first.");
            
        }
        System.out.println("Select an exam to add a question:");
        for (Exam e : exams) {
            System.out.println(e.getExamId() + ". " + e.getExamName());
        }
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the exam ID: ");
        int examId = scanner.nextInt();
        scanner.nextLine();
        
        
        Exam selectedExam = examService.fetchExamById(examId);
        if (selectedExam == null) {
            System.out.println("Invalid exam ID.");
           
        }
	
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter question Id:");
		int questionId = sc.nextInt();
		
		System.out.println("Enter question:");
		String questionName = scanner.nextLine();
		
		System.out.println("Enter Opiton1:");
		String option1 = scanner.nextLine();
		
		System.out.println("Enter Opiton2:");
		String option2 = scanner.nextLine();
		
		System.out.println("Enter Opiton3:");
		String option3 = scanner.nextLine();
		
		System.out.println("Enter Opiton4:");
		String option4 = scanner.nextLine();
		
		System.out.println("Enter CorrectAnswer:");
		String crtAnswer = scanner.nextLine();
		
		System.out.println("Enter the marks for this question:");
		int marks = scanner.nextInt();
		
		
		Question newQuestion= new Question();
		newQuestion.setQuestionId(questionId);
		newQuestion.setQuestion(questionName);
		newQuestion.setOption1(option1);
		newQuestion.setOption2(option2);
		newQuestion.setOption3(option3);
		newQuestion.setOption4(option4);
		newQuestion.setCorrectAnswer(crtAnswer);
		newQuestion.setMarks(marks);
		newQuestion.setExam(selectedExam);
		
		questionRepository.save(newQuestion);
		
		 System.out.println("Question added to the exam successfully.");
		
	}
	public List<Question> getQuestions(){
		List<Question> questions = questionRepository.findAll();
		System.out.println("All Exams");
		questions.forEach(question -> System.out.println("QuestionId:" + question.getQuestionId() + ", Question:" + question.getQuestion() + ", Option1: " + question.getOption1() + ", Option2: " + question.getOption2() + ", Option3: " + question.getOption3() + ", Option4: " + question.getOption4() + ", Correct Option: " + question.getCorrectAnswer() + ", Marks: " + question.getMarks() + ", Exam: " + question.getExam()));
		return questions;

	}
	public Question getQuestionById(int questionId){
	
		if (questionRepository.existsById(questionId)) {
	        Optional<Question> questionOptional = questionRepository.findById(questionId);
	        if (questionOptional.isPresent()) {
	            Question question = questionOptional.get();
	            System.out.println("Question found: " + question);
	            return question;
	        } else {
	            System.out.println("Exam found by ID, but data not available.");
	        }
	    } else {
	        System.out.println("Exam not found with ID: " + questionId);
	    }
	    return null;

	}
	
	
	public void deleteQuestionById() {
		Scanner scanner = new Scanner(System.in);
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Question Id:");
        int questionId = sc.nextInt();
        
        if(questionRepository.existsById(questionId)) {
        	questionRepository.deleteById(questionId);
        	System.out.println("exam deleted successfully");
        }else {
        	 System.out.println("exam not found with ID: " + questionId);
        }
	}
	public void updateQuestion() {
		
		Scanner scanner = new Scanner(System.in);
		  System.out.println("Enter the ID of the question to update:");
	      int questionId = scanner.nextInt();
	      scanner.nextLine();
	      
	      Optional<Question> optionalQuestion = questionRepository.findById(questionId);
	      if (optionalQuestion.isPresent()) {
	          Question question = optionalQuestion.get();
	          
	          System.out.println("Enter the question to update");
	          String questionName = scanner.nextLine();
	          
	          System.out.println("Enter the option1 to update: ");
	          String option1 = scanner.nextLine();
	          
	          System.out.println("Enter the option2 to update: ");
	          String option2 = scanner.nextLine();
	          
	          System.out.println("Enter the option3 to update: ");
	          String option3 = scanner.nextLine();
	          
	          System.out.println("Enter the option4 to update: ");
	          String option4 = scanner.nextLine();
	          
	          System.out.println("Enter the correct option to update: ");
	          String crtOption = scanner.nextLine();
	          
	          System.out.println("Enter the updated marks: ");
	          int marks = scanner.nextInt();
	          
	          question.setQuestion(questionName);
	          question.setOption1(option1);
	          question.setOption2(option2);
	          question.setOption3(option3);
	          question.setOption4(option4);
	          question.setCorrectAnswer(crtOption);
	          question.setMarks(marks);
	          
	          questionRepository.save(question);
	          System.out.println("Question updated ");
	          
	      }else {
	    	  System.out.println("QUestion not found with the id " + questionId);
	      }
	}

}

