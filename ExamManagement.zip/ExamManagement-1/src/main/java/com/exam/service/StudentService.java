package com.exam.service;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.model.Exam;
import com.exam.model.Question;
import com.exam.model.Report;
import com.exam.model.Student;
import com.exam.repository.StudentRepository;

@Service
public class StudentService {

	@Autowired
	StudentRepository studentRepository;
	
	@Autowired
	QuestionService questionService;
	
	
	
	
	public void addStudent() {
		
		Scanner scanner = new Scanner(System.in);
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter student Id : ");
		int studentId = sc.nextInt();
		
		System.out.println("Enter student name: ");
		String stdName = scanner.nextLine();
		
		System.out.println("Enter student password: ");
		String stdPassword = scanner.nextLine();
		
		System.out.println("Enter student Email: ");
		String stdEmail = scanner.nextLine();
		
		System.out.println("Enter student enroll number: ");
		String stdEnroll = scanner.nextLine();
		
		Student students = new Student();
		students.setStudentId(studentId);
		students.setStudentName(stdName);
		students.setStudentPassword(stdPassword);
		students.setStudentEmail(stdEmail);
		students.setEnrolExam(stdEnroll);
		
		studentRepository.save(students);
		System.out.println("Student detalis updated");
		
		
		
		
	}
	public List<Student> fetchAllStudents(){
		List<Student> students = studentRepository.findAll();
		System.out.println("All students:");
		students.forEach(student -> System.out.println("Student ID: "+ student.getStudentId() + ", Student Name: "+student.getStudentName()+", Student Password: "+ student.getStudentPassword()+", Student Email; "+ student.getStudentEmail()+", Student Enroll number:"+ student.getEnrolExam()));
		return students;
		
	}
	public Student fetchStudentId(int studentId) {
		
		if (studentRepository.existsById(studentId)) {
	        Optional<Student> studentOptional = studentRepository.findById(studentId);
	        if (studentOptional.isPresent()) {
	            Student student = studentOptional.get();
	            System.out.println("Student found: " + student);
	            return student;
	        } else {
	            System.out.println("Student found by ID, but data not available.");
	        }
	    } else {
	        System.out.println("Student not found with ID: " + studentId);
	    }
	    return null;
	}
	public void deletebyId() {
		Scanner scanner = new Scanner(System.in);
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Student Id:");
        int studentId = sc.nextInt();
        
        if(studentRepository.existsById(studentId)) {
        	studentRepository.deleteById(studentId);
        	System.out.println("student deleted successfully");
        }else {
        	 System.out.println("student not found with ID: " + studentId);
        }
	}
	public void updateStudent() {
		Scanner scanner = new Scanner(System.in);
		  System.out.println("Enter the ID of the student to update:");
	      int studentId = scanner.nextInt();
	      scanner.nextLine(); 

	      Optional<Student> optionalStudent = studentRepository.findById(studentId);
	      if (optionalStudent.isPresent()) {
	    	  
	          Student student = optionalStudent.get();
	          
	          System.out.println("Enter updated student name: ");
	  		String stdName = scanner.nextLine();
	  		
	  		System.out.println("Enter updated student password: ");
	  		String stdPassword = scanner.nextLine();
	  		
	  		System.out.println("Enter updated student Email: ");
	  		String stdEmail = scanner.nextLine();
	  		
	  		System.out.println("Enter updated student enroll number: ");
	  		String stdEnroll = scanner.nextLine();
	  		
	  		student.setStudentName(stdName);
	  		student.setStudentPassword(stdPassword);
	  		student.setStudentEmail(stdEmail);
	  		student.setEnrolExam(stdEnroll);
	  		
	  		studentRepository.save(student);
	  		
	  		System.out.println("Student detalis updated");
	          
	      }else {
	          System.out.println("Student not found with ID: " + studentId);
	      }
	}
	
	
}
