package com.exam.service;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.model.Exam;
import com.exam.model.Question;
import com.exam.model.Report;
import com.exam.model.Student;
import com.exam.repository.ReportRepository;
import com.exam.repository.StudentRepository;

@Service
public class ReportService {

	@Autowired
	ReportRepository reportRepository;
	
	//@Autowired
	//StudentRepository studentRepository;
	
	@Autowired
	QuestionService questionService;
	
	@Autowired
	ExamService examService;

    @Autowired
    StudentService studentService;
	
public void startExam() {
		
		Scanner scanner = new Scanner(System.in);
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter your Student Id: ");
		int studentId = sc.nextInt();
		
		System.out.println("Enter exam Id: ");
		int examId = sc.nextInt();
		
		System.out.println("Enter your name: ");
		String studentName = scanner.nextLine();
		
		
		Exam examSubject = examService.fetchExamById(examId);
		Student newStudent1 = studentService.fetchStudentId(studentId);
		
		List<Question> questions = questionService.getQuestions();
		
		int totalQuestion = questions.size();
		int correctAnswer = 0;
		
		
		
		for (Question question : questions) {
			System.out.println(question.getQuestion());
			System.out.println("1. " + question.getOption1());
			System.out.println("2. " + question.getOption2());
			System.out.println("3. " + question.getOption3());
			System.out.println("4. " + question.getOption4());
			
			System.out.print("Enter your answer (1, 2, 3, or 4): ");

            String userAnswer = scanner.nextLine();
            
            if (userAnswer.equals(question.getCorrectAnswer())) {
            	correctAnswer++ ;
            }

		}
		
		double score = ((double) correctAnswer / totalQuestion) * 100;
		
		
		Report reports = new Report();
		reports.setStudentName(studentName);
		reports.setTotalQuestion(totalQuestion);
		reports.setCorrectAnswer(correctAnswer);
		reports.setScore(score);
		reports.setStudent(newStudent1);
		reports.setExam(examSubject);
		
		reportRepository.save(reports);
		System.out.println("Report saved");
		
				
	}
	
	public List<Report> fetchAllReports(){
		List<Report> reports = reportRepository.findAll();
		System.out.println("All reports:");
		reports.forEach(report -> System.out.println("Report ID: "+ report.getReoprtId() + ", Student Name: "+report.getStudentName()+", Total Question: "+ report.getTotalQuestion()+", Correct Option; "+ report.getCorrectAnswer()+", Student Score:"+ report.getScore()));
		return reports;
	}
	
	
	public List<Report> fetchReportByStudentId(int studentId) {
        List<Report> report = reportRepository.findReportByStudentId(studentId);
        if (report != null) {
            System.out.println("Report found for student with ID: " + studentId);
            for(Report report1: report) {
            System.out.println(report1);
            }
            return report;
        } else {
            System.out.println("Report not found for student with ID: " + studentId);
            return null;
        }
    }
}
