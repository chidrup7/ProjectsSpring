package com.exam.service;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.model.Exam;
import com.exam.repository.ExamRepository;

import lombok.experimental.UtilityClass;

@Service
public class ExamService {
	
	@Autowired
	ExamRepository examRepository;
	
	public void addExam() {
		Scanner scanner = new Scanner(System.in);
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Exam Id:");
        int examId = sc.nextInt();

		
		System.out.println("Enter Exam name:");
        String examName = scanner.nextLine();

        System.out.println("Enter Exam Created By:");
        String createdBy = scanner.nextLine();
        
        System.out.println("Enter Subject:");
        String subject = scanner.nextLine();
        
        System.out.println("Enter Exam Description:");
        String description = scanner.nextLine();
        

        Exam newExam = new Exam();
        newExam.setExamId(examId);
        newExam.setExamName(examName);
        newExam.setCreatedBy(createdBy);
        newExam.setSubject(subject);
        newExam.setDescription(description);
        

        examRepository.save(newExam);
        System.out.println("Exam added successfully!");
	}
	
	public List<Exam> ListExams() {
		List<Exam> exams = examRepository.findAll();
		System.out.println("All Exams");
		exams.forEach(exam -> System.out.println(" Exam ID: "+exam.getExamId()+", Exam Name: "+exam.getExamName()+", Created By :" + exam.getCreatedBy()+", Subject: " + exam.getSubject()+", Description: "+exam.getDescription()));
		return exams;
		}
	
	public Exam fetchExamById(int examId){
		
		if (examRepository.existsById(examId)) {
	        Optional<Exam> examOptional = examRepository.findById(examId);
	        if (examOptional.isPresent()) {
	            Exam exam = examOptional.get();
	            System.out.println("Exam found: " + exam);
	            return exam;
	        } else {
	            System.out.println("Exam found by ID, but data not available.");
	        }
	    } else {
	        System.out.println("Exam not found with ID: " + examId);
	    }
	    return null;
		
	}
	
	public void deleteExamById() {
		Scanner scanner = new Scanner(System.in);
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Exam Id:");
        int examId = sc.nextInt();
        
        if(examRepository.existsById(examId)) {
        	examRepository.deleteById(examId);
        	System.out.println("exam deleted successfully");
        }else {
        	 System.out.println("exam not found with ID: " + examId);
        }
		
	}
	public void updateExam() {

		Scanner scanner = new Scanner(System.in);
	  System.out.println("Enter the ID of the exam to update:");
      int examId = scanner.nextInt();
      scanner.nextLine(); 

      Optional<Exam> optionalExam = examRepository.findById(examId);
      if (optionalExam.isPresent()) {
          Exam exam = optionalExam.get();

          System.out.println("Enter updated exam name:");
          String examName = scanner.nextLine();
          
          System.out.println("Enter updated exan createdby");
          String createdBy = scanner.nextLine();
          
          System.out.println("Enter updated exam subject");
          String subject = scanner.nextLine();

          System.out.println("Enter updated exam description:");
          String description = scanner.nextLine();

          exam.setExamId(examId);
          exam.setExamName(examName);
          exam.setCreatedBy(createdBy);
          exam.setSubject(subject);
          exam.setDescription(description);
          
          examRepository.save(exam);
          System.out.println("Exam updated successfully.");
      } else {
          System.out.println("Exam not found with ID: " + examId);
      }
  }
}
