package com.exam.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Student")
public class Student {

	
	@Id
	int student_id;
	String student_name;
	String student_email;
	String student_password;
	String enrol_exam;
	
	
	public Student() {
		super();
	}


	public Student(int studentId, String studentName, String studentEmail, String studentPassword, String enrolExam) {
		super();
		this.student_id = studentId;
		this.student_name = studentName;
		this.student_email = studentEmail;
		this.student_password = studentPassword;
		this.enrol_exam = enrolExam;
	}


	public int getStudentId() {
		return student_id;
	}


	public void setStudentId(int studentId) {
		this.student_id = studentId;
	}


	public String getStudentName() {
		return student_name;
	}


	public void setStudentName(String studentName) {
		this.student_name = studentName;
	}


	public String getStudentEmail() {
		return student_email;
	}


	public void setStudentEmail(String studentEmail) {
		this.student_email = studentEmail;
	}


	public String getStudentPassword() {
		return student_password;
	}


	public void setStudentPassword(String studentPassword) {
		this.student_password = studentPassword;
	}


	public String getEnrolExam() {
		return enrol_exam;
	}


	public void setEnrolExam(String enrolExam) {
		this.enrol_exam = enrolExam;
	}


	@Override
	public String toString() {
		return "Student [studentId=" + student_id + ", studentName=" + student_name + ", studentEmail=" + student_email
				+ ", studentPassword=" + student_password + ", enrolExam=" + enrol_exam + "]";
	}
	
	
	
}
