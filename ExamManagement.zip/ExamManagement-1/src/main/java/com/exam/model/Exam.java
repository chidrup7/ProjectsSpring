package com.exam.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Exam")
public class Exam {
	
	
	
	@Id
	int examId;
	String examName;
	String createdBy;
	String subject;
	String description;
	
	

	public Exam() {
		super();
	}

	public Exam(int examId, String examName, String createdBy, String subject, String description
			) {
		super();
		this.examId = examId;
		this.examName = examName;
		this.createdBy = createdBy;
		this.subject = subject;
		this.description = description;
		
	}

	public int getExamId() {
		return examId;
	}

	public void setExamId(int examId) {
		this.examId = examId;
	}

	public String getExamName() {
		return examName;
	}

	public void setExamName(String examName) {
		this.examName = examName;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	
	@Override
	public String toString() {
		return "Exam [examId=" + examId + ", examName=" + examName + ", createdBy=" + createdBy + ", subject=" + subject
				+ ", description=" + description + "]";
	}
	
	
	
	
	
	

}
