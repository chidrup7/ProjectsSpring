package com.exam.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Report")
public class Report {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int reportId;
	String studentName;
	int totalQuestion;
	int correctAnswer;
	double score;
	
	@OneToOne
	@JoinColumn(name = "student_id")
	private Student student;
	
	@OneToOne
	private Exam exam;

	public Report() {
		super();
	}

	public Report(int reportId, String studentName, int totalQuestion, int correctAnswer, double score,
			Student student, Exam exam) {
		super();
		this.reportId = reportId;
		this.studentName = studentName;
		this.totalQuestion = totalQuestion;
		this.correctAnswer = correctAnswer;
		this.score = score;

		this.student = student;
		this.exam = exam;
	}

	public int getReoprtId() {
		return reportId;
	}

	public void setReoprtId(int reportId) {
		this.reportId = reportId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public int getTotalQuestion() {
		return totalQuestion;
	}

	public void setTotalQuestion(int totalQuestion) {
		this.totalQuestion = totalQuestion;
	}

	public int getCorrectAnswer() {
		return correctAnswer;
	}

	public void setCorrectAnswer(int correctAnswer) {
		this.correctAnswer = correctAnswer;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Exam getExam() {
		return exam;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}

	@Override
	public String toString() {
		return "Report [reportId=" + reportId + ", studentName=" + studentName + ", totalQuestion=" + totalQuestion
				+ ", correctAnswer=" + correctAnswer + ", score=" + score  + ", student="
				+ student + ", exam=" + exam + "]";
	}

	
	
	
	
	
}
