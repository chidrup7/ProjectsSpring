package com.exam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.exam.model.Report;

public interface ReportRepository extends JpaRepository<Report, Integer> {
	@Query(value = "SELECT * FROM Report r WHERE r.student_id= :id", nativeQuery = true)
	List<Report> findReportByStudentId(@Param("id") int id);
}
