package com.exam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.exam.console.Main;

@SpringBootApplication
@ComponentScan(basePackages = "com.exam")
public class ExamManagement1Application implements CommandLineRunner {

    private final Main main;

    @Autowired
    public ExamManagement1Application(Main main) {
        this.main = main;
    }

    public static void main(String[] args) {
        SpringApplication.run(ExamManagement1Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        main.examMain();
    }
}







