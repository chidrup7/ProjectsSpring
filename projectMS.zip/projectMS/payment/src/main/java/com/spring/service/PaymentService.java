package com.spring.service;

import com.spring.model.Payment;

public interface PaymentService {
	
	public Payment doPayment(Payment payment);

}
