package com.spring.service;


import com.spring.model.Login;


public interface LoginService {
	
	public Login addCustomer(Login login);
	public String deleteCustomer(int id) ;
	public Login updateCustomer(int id, Login login);
}
