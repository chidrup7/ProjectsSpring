package com.spring.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Login")
public class Login {
	
	@Id
	@GeneratedValue
	private int customerId;
	private String customerName;
	private double customerNumber;
	private String customerEmail;
	
	public Login() {
		super();
	}

	

	public Login(int customerId, String customerName, double customerNumber, String customerEmail) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerNumber = customerNumber;
		this.customerEmail = customerEmail;
	}



	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public double getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(double customerNumber) {
		this.customerNumber = customerNumber;
	}



	public String getCustomerEmail() {
		return customerEmail;
	}



	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	
	
	
	
	

}
