package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.Login;
import com.spring.repository.LoginRepository;


@Service
public class LoginServiceImpl implements LoginService {
	
	@Autowired
	public LoginRepository loginRepository;

	@Override
	public Login addCustomer(Login login) {
		// TODO Auto-generated method stub
		return loginRepository.save(login);
		
	}

	@Override
	public String deleteCustomer(int id) {
		// TODO Auto-generated method stub
		loginRepository.deleteById(id);
		return "Customer with Customer Id "+id+" has been deleted";
		
	}

	@Override
	public Login updateCustomer(int id, Login login) {
		// TODO Auto-generated method stub
		Login login1 =loginRepository.findById(id).orElse(null);
		login1.setCustomerName(login.getCustomerName());
		login1.setCustomerNumber(login.getCustomerNumber());
		login1.setCustomerEmail(login.getCustomerEmail());
		return loginRepository.save(login1);
	}

}
