package com.spring.service;

import java.util.List;

import com.spring.model.FoodMenu;

public interface FoodService {
	
	public FoodMenu addFood(FoodMenu foodMenu);
	public String deleteFoodByName(String foodName);
	public List<FoodMenu> fetchFoodByCategory(String foodCategory);

}
