package com.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.FoodMenu;
import com.spring.repository.FoodRepository;

@Service
public class FoodServiceImpl implements FoodService {

	
	@Autowired
	private FoodRepository foodRepository;
	
	
	@Override
	public FoodMenu addFood(FoodMenu foodMenu) {
		return foodRepository.save(foodMenu);
	}


	@Override
	public String deleteFoodByName(String foodName) {
		// TODO Auto-generated method stub
		foodRepository.deleteByFoodName(foodName);
		return foodName + "has been removed";
	}


	@Override
	public List<FoodMenu> fetchFoodByCategory(String foodCategory) {
		// TODO Auto-generated method stub
		List<FoodMenu> FoodMenu = foodRepository.findByFoodCategory(foodCategory);
//		List<FoodMenu> FoodMenu = foodRepository.findFoodCategory(foodCategory);
		return FoodMenu;
	}

}
