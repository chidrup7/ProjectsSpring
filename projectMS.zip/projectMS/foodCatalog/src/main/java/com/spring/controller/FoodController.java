package com.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.model.FoodMenu;
import com.spring.service.FoodService;

@RestController
@RequestMapping("/food")
public class FoodController {
	
	@Autowired
	private FoodService foodService;
	
	@PostMapping("/add")
	public FoodMenu addFood(@RequestBody FoodMenu foodMenu) {
		return foodService.addFood(foodMenu);
	}
	
	@GetMapping("/foodCategory/{foodCategory}")
	public List<FoodMenu> fetchByFoodCategory(@PathVariable String foodCategory){
		return foodService.fetchFoodByCategory(foodCategory);
	}
	
	@DeleteMapping("/remove/{foodName}")
	public String deleteByfoodName(@PathVariable String foodName) {
		return foodService.deleteFoodByName(foodName);
	}
}
