package com.spring.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.spring.model.FoodMenu;

@Repository
public interface FoodRepository extends JpaRepository<FoodMenu, Integer> {
	
	
	public List<FoodMenu> findByFoodCategory(String foodCategory);
	public void deleteByFoodName(String foodName);
	
//	@Query(value = "SELECT * FROM Food_Menu f WHERE f.foodCategory = ")
//	List<FoodMenu> findFoodCategory(String foodCategory);
}
