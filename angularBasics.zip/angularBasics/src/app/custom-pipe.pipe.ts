import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'customPipe'
})
export class CustomPipePipe implements PipeTransform {

  nvalue:any;
  transform(value: number): any {
    return value *100;
  }

}
