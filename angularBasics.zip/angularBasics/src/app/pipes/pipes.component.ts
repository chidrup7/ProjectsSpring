import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrl: './pipes.component.css'
})
export class PipesComponent implements OnInit {

  dateToday: any;
  name: any;
  meterValue: number = 0;

  constructor(){}

  ngOnInit(): void {

    this.dateToday = new Date();
    this.name="angular";
    
  }

}
