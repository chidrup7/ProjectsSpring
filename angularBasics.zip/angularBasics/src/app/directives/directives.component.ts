import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrl: './directives.component.css'
})
export class DirectivesComponent implements OnInit{

  isVisible = true;
  items = ['Item 1','Item 2', 'Item 3'];
  value = 'case1';
  condition1=false;
  isRed =true;
  fontSize = 16;
  name = '';
  ngOnInit(): void {
    
  }

}
