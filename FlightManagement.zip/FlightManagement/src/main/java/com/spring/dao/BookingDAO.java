package com.spring.dao;

public class BookingDAO {

}
