package com.spring.dao;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import com.spring.model.Flight;

@Component
public class FlightDAO {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Transactional
	public void addFlight(Flight flight) {
		this.hibernateTemplate.save(flight);
	}
	
	public void deleteFlightById(int id) {
		this.hibernateTemplate.delete(hibernateTemplate.get(Flight.class, id));
	}

}
