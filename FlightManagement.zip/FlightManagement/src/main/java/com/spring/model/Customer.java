package com.spring.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Customer")

public class Customer {

	
	@Id
	int custId;
	String custName;
	String userName;
	String Password;
	String email;
	Long phonenumber;
	
	
	public Customer() {
		super();
	}


	public Customer(int custId, String custName, String userName, String password, String email, Long phonenumber) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.userName = userName;
		Password = password;
		this.email = email;
		this.phonenumber = phonenumber;
	}


	public int getCustId() {
		return custId;
	}


	public void setCustId(int custId) {
		this.custId = custId;
	}


	public String getCustName() {
		return custName;
	}


	public void setCustName(String custName) {
		this.custName = custName;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getPassword() {
		return Password;
	}


	public void setPassword(String password) {
		Password = password;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public Long getPhonenumber() {
		return phonenumber;
	}


	public void setPhonenumber(Long phonenumber) {
		this.phonenumber = phonenumber;
	}


	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", userName=" + userName + ", Password="
				+ Password + ", email=" + email + ", phonenumber=" + phonenumber + "]";
	}
	
	
	
	
	
}
