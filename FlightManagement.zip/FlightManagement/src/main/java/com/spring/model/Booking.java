package com.spring.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Booking")
public class Booking {

	@Id
	int bookingId;
	float bookingAmount;
	int seatNumber;
	
	@OneToOne
	Customer customer;
	
	@OneToOne
	Flight flight;

	public Booking() {
		super();
	}

	public Booking(int bookingId, float bookingAmount, int seatNumber, Customer customer, Flight flight) {
		super();
		this.bookingId = bookingId;
		this.bookingAmount = bookingAmount;
		this.seatNumber = seatNumber;
		this.customer = customer;
		this.flight = flight;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public float getBookingAmount() {
		return bookingAmount;
	}

	public void setBookingAmount(float bookingAmount) {
		this.bookingAmount = bookingAmount;
	}

	public int getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Flight getFlight() {
		return flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}

	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", bookingAmount=" + bookingAmount + ", seatNumber=" + seatNumber
				+ ", customer=" + customer + ", flight=" + flight + "]";
	}
	
	
}
