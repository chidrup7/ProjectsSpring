create database hospital;

use hospital;

create table Patient
(
patient_id int primary key,
first_name varchar(20) not null,
last_name varchar(10),
dob date not null,
address varchar(50) not null,
phone_number bigint not null,
patient_relatives varchar(50)
);


insert into Patient values(001, 'Ram', 'Singh', '1998-02-11', 'HSR, bangalore', 9323456789,'Kumar');
insert into Patient values(002, 'Ramesh', 'Reddy', '1999-03-10', 'BTM, bangalore', 9008733445,'Manish');
insert into Patient values(003, 'Anil', 'Kalavara', '1989-10-02', 'HSR, bangalore', 9230987123,'Shoumya');
insert into Patient values(004, 'Lava', 'Kumar', '1999-02-01', 'JPNagar, bangalore', 9876543210,'Chethan');
insert into Patient values(005, 'Sujith', 'TL', '1995-06-04', 'Hoskote, bangalore', 8973512789,'Vinod');
insert into Patient values(006, 'Naga', 'Arjun', '1998-02-11', 'Marthahalli, bangalore', 9123456788,'vaishu');
insert into Patient values(007, 'Darshan', 'L', '2020-04-20', 'BTM, bangalore', 9008456789,'Sahana');

select * from Patient;

create table Doctor
(
doctor_id int primary key,
first_name varchar(20) not null,
last_name varchar(10),
specialization varchar(20) not null,
phone_number bigint not null,
available_from time,
available_to time,
leave date
);

insert into Doctor values(1001,'Adith','Dev','ENT',9876543212,'09:00:00','13:00:00','2023-06-10');
insert into Doctor values(1002,'Arya','Dev','Cardiology',9123456789,'10:00:00','13:00:00','2023-06-21');
insert into Doctor values(1005,'Adhya','Ganesh','Orthopaedic',9654378932,'12:00:00','18:00:00','2023-06-30');
insert into Doctor values(1006,'Chethak','Kumar','Surgery',8976543212,'13:00:00','20:00:00','2023-06-20');
insert into Doctor values(1007,'Akhil','K','ENT',98765452727,'14:00:00','20:00:00','2023-06-06');
insert into Doctor values(1008,'Sanath','Prakash','General',8012834759,'09:00:00','19:00:00','2023-07-01');

SELECT * FROM Doctor;

create table insurance(
insurance_id int primary key,
patient_id int foreign key references Patient not null,
insurance_company varchar(50) not null,
policy_number int not null,
insurance_amount int not null,
insurance_start_date date not null,
insurance_end_date date not null
);

INSERT INTO insurance values(20011, 002,'Bajaj', 102030, 300000,'2000-03-01','2050-12-30');
INSERT INTO insurance values(20021, 001,'HDFC', 23455, 600000,'2010-03-01','2060-12-30');
INSERT INTO insurance values(20010, 005,'Bajaj', 102051, 400000,'2020-03-01','2053-12-30');
INSERT INTO insurance values(20013, 003,'Aditya Birla', 45667, 200000,'2007-03-01','2056-12-30');
INSERT INTO insurance values(20045, 007,'Star Health', 56734, 800000,'2012-03-01','2065-12-30');

SELECT * FROM insurance;

create table Appointment(
appointment_id int primary key,
patient_id int foreign key references Patient not null,
doctor_id int foreign key references Doctor not null,
appointment_date date,
appointment_time time
);

INSERT INTO Appointment values(4001,001,1001,'2023-06-05','10:00:00');
INSERT INTO Appointment values(4003,003,1005,'2023-06-10','12:30:00');
INSERT INTO Appointment values(4004,004,1008,'2023-06-12','14:15:00');
INSERT INTO Appointment values(4005,006,1006,'2023-06-08','13:30:00');
INSERT INTO Appointment values(4006,007,1001,'2023-06-06','11:00:00');


create table Visits(
visit_id int primary key,
patient_id int foreign key references Patient not null,
doctor_id int foreign key references Doctor not null,
visit_date date,
visit_time time
);

INSERT INTO Visits values (5001, 001,1002,'2020-10-02','10:02:00');
INSERT INTO Visits values (5002, 002,1002,'2022-11-12','11:00:00');
INSERT INTO Visits values (5003, 001,1005,'2021-04-10','12:02:00');
INSERT INTO Visits values (5004, 004,1001,'2019-09-12','14:02:00');
INSERT INTO Visits values (5005, 001,1006,'2023-02-13','15:02:00');
INSERT INTO Visits values (5006, 005,1007,'2018-10-02','16:06:00');
INSERT INTO Visits values (5007, 001,1008,'2021-07-20','13:00:00');
INSERT INTO Visits values (5008, 003,1005,'2022-12-21','15:20:00');

SELECT * FROM Visits;

---------------------------------------------------------------------------------------------------------------------
--1. Get patients having insurance with patient and insurance details--
SELECT i.patient_id, first_name, last_name, address, phone_number,insurance_id, insurance_company, policy_number, 
insurance_amount, insurance_start_date, insurance_end_date FROM
Patient p
RIGHT OUTER JOIN
insurance i
on p.patient_id = i.patient_id;

select * from insurance;

--2. Get all the available timeslots for a specific doctor and for a specific date--

/*This query first checks if the doctor is on leave or not and then checks if he has any appointments on particular date 
or not and it returns the doctor details and timeslot if he is available.
If the doctor is unavailable no values will be returned*/

SELECT d.doctor_id, d.first_name, d.last_name, d.specialization, d.phone_number, d.available_from, d.available_to FROM
Doctor d
JOIN
Appointment a
on d.doctor_id = a.doctor_id
WHERE d.leave!='2023-06-10' AND a.appointment_date !='2023-06-10' AND d.first_name ='Sanath';


--FOR REFERENCE--
SELECT d.doctor_id, d.first_name, d.last_name, d.specialization, d.phone_number, d.available_from, d.available_to, 
d.leave, a.appointment_date FROM
Doctor d
JOIN
Appointment a
on d.doctor_id = a.doctor_id

--3. Get the doctor who has handled most number of patient--

SELECT doc,t2.doctor_id, first_name, last_name, specialization FROM
(
SELECT DENSE_RANK() over (ORDER BY top_doctor DESC) AS doc, doctor_id
FROM
(
SELECT doctor_id, COUNT(doctor_id) as top_doctor
from Visits
GROUP BY doctor_id
)t1
)t2
JOIN 
Doctor d 
ON t2.doctor_id = d.doctor_id
WHERE t2.doc=1;

--4. Get the Patient who has visited most number of time--

SELECT most_visit, t2.patient_id, first_name, last_name FROM
(
SELECT DENSE_RANK() over (ORDER BY pat DESC) AS most_visit, patient_id
FROM
(
SELECT patient_id, COUNT(patient_id) as pat
from Visits
GROUP BY patient_id
)t1
)t2
JOIN 
Patient p 
ON t2.patient_id = p.patient_id
WHERE t2.most_visit=1;

--5. Display appointment list for a specific doctor. The list should include the name of patient and patient's relative--

SELECT appointment_id, d.doctor_id, d.first_name, d.last_name, appointment_date,appointment_time, p.first_name, p.last_name, patient_relatives 
FROM 
Appointment a
JOIN
Patient p
ON a.patient_id = p.patient_id
JOIN
Doctor d 
ON a.doctor_id = d.doctor_id