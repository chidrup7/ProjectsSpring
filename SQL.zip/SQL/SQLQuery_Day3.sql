
---1---
select * from Sales.Customer

select count(*)
from Sales.Customer

---2---
select * from Production.Product

select max(ListPrice) as MaxPrice,
min(ListPrice) as MinPrice,
avg(ListPrice) as AvgPrice
from Production.Product

---3---
select * from Sales.SalesOrderDetail

select sum(OrderQty) as total , ProductID
from Sales.SalesOrderDetail
group by ProductID

---4---
select * from Sales.SalesOrderDetail

select count(*) as counts , SalesOrderID
from Sales.SalesOrderDetail
group by SalesOrderID

---5---
select * from Production.Product

select count(*) as counts , ProductLine
from Production.Product
group by ProductLine

---6---
select * from  Sales.SalesOrderHeader

select CustomerID, count(*) as counts , year(OrderDate) as yr
from Sales.SalesOrderHeader
group by CustomerID, year(OrderDate)

---7---
select * from Sales.SalesOrderDetail

select SalesOrderID , sum(LineTotal) as sums
from Sales.SalesOrderDetail
group by LineTotal, SalesOrderID
having sum(LineTotal) > 1000


---8---

select * from Production.Product

select ProductModelID, count(*) 
from Production.Product
group by ProductModelID
having count(*) = 1

---9---
select sum(orderqty) as sum,sd.ProductID,OrderDate
from Sales.SalesOrderHeader as so,Sales.SalesOrderDetail as sd,Production.Product as pd
where so.SalesOrderID =sd.SalesOrderID and pd.ProductID =sd.ProductID
group by sd.ProductID ,OrderDate


---10--
select * from HumanResources.vEmployeeDepartment
select * from 
(select FirstName, StartDate,
DENSE_RANK() over (order by StartDate asc) as rank
from HumanResources.vEmployeeDepartment)dr
where dr.rank=3



---11--
SELECT *
FROM
(select DENSE_RANK() over(order by sum desc) as ranks,customerID,sum
from
(select  customerID,count(salesorderId) as sum
from sales.SalesOrderHeader
group by CustomerID
) t1
) t2
WHERE t2.ranks = 2



---12---
Select *
from
(select ROW_NUMBER() Over(partition by ProductSubcategoryID order by standardcost desc) as rn, 
count(*) over(partition by ProductSubcategoryID) as cn ,ProductSubcategoryID, StandardCost
from Production.Product) t1
where t1.rn * 1.0 / t1.cn <= 0.25

---13---

CREATE SEQUENCE SequenceCounter
    AS INT
    START WITH 100
    INCREMENT BY 100;



   SELECT NEXT VALUE FOR SequenceCounter AS Counter;
--creating a temporary local table
    CREATE TABLE #temp_tbl_Local
    (
    ecode INT,
    ename VARCHAR(20),
    salary INT
    )
--inserting the values into the table with the sequence counter
    INSERT INTO #temp_tbl_Local(ecode, ename, salary)
    VALUES(NEXT VALUE FOR SequenceCounter, 'Ram' , 10000);
    INSERT INTO #temp_tbl_Local(ecode, ename, salary)
    VALUES(NEXT VALUE FOR SequenceCounter, 'Ravi' , 20000);
    INSERT INTO #temp_tbl_Local(ecode, ename, salary)
    VALUES(NEXT VALUE FOR SequenceCounter, 'Ramesh' , 30000);
    INSERT INTO #temp_tbl_Local(ecode, ename, salary)
    VALUES(NEXT VALUE FOR SequenceCounter, 'Suresh' , 40000);
    INSERT INTO #temp_tbl_Local(ecode, ename, salary)
    VALUES(NEXT VALUE FOR SequenceCounter, 'Guru' , 50000);
    SELECT *FROM #temp_tbl_Local



--creating a sequence for global table
--creating a global table
CREATE TABLE ##temp_tbl_global
    (
    ecode int,
    ename varchar(20),
    salary int
    )
    INSERT into ##temp_tbl_global VALUES(NEXT VALUE FOR SequenceCounter,'Mahesh',10000);
    INSERT into ##temp_tbl_global VALUES(NEXT VALUE FOR SequenceCounter,'Esha',20000);
    INSERT into ##temp_tbl_global VALUES(NEXT VALUE FOR SequenceCounter,'Moosa',10000);
    INSERT into ##temp_tbl_global VALUES(NEXT VALUE FOR SequenceCounter,'Arun',50000);
    INSERT into ##temp_tbl_global VALUES(NEXT VALUE FOR SequenceCounter,'Mosranna',90000);
    INSERT into ##temp_tbl_global VALUES(NEXT VALUE FOR SequenceCounter,'Chandu',80000);
    SELECT * FROM ##temp_tbl_global
