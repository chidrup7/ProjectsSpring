create database citiusdb

use citiusdb

create table customers
(
id int primary key,
cname varchar(25),
city varchar(20),
phno numeric(10)
)
select *from customers
insert into customers values(1,'gowda','USA','777')
insert into customers(cname,id,city,phno) values('gowda',5,'blr','1234')
insert into customers(id,cname,city) values(6,'rao','smg')
delete from customers where id=4
delete from customers where phno is null
update customers set city = 'UK' where id=1
select cname from customers
where id=1