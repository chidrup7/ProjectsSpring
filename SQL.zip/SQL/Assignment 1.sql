--DAY 2--

/*1*/
SELECT BusinessEntityID, FirstName, MiddleName, LastName, ModifiedDate 
FROM Person.Person
WHERE ModifiedDate > '2000-12-29';

/*2*/
SELECT BusinessEntityID, FirstName, MiddleName, LastName, ModifiedDate 
FROM Person.Person
/*WHERE YEAR(ModifiedDate) = 2011;*/
WHERE ModifiedDate BETWEEN '2000-12-01'AND '2000-12-31';

/*3*/
SELECT ProductId, Name
FROM Production.Product
WHERE Name LIKE 'Chain%';

/*4*/
SELECT BusinessEntityID, FirstName, MiddleName, LastName 
FROM Person.Person
WHERE MiddleName ='E' OR MiddleName='B';
/*Where MiddleName LIKE '[E,B]'*/

/*5*/
SELECT SalesOrderID, OrderDate, TotalDue
FROM Sales.SalesOrderHeader
WHERE OrderDate BETWEEN '2001-09-01' AND '2001-09-30' AND TotalDue > 1000;

/*6*/
SELECT *
FROM Sales.SalesOrderHeader
WHERE TotalDue > 1000 AND SalesPersonID = 279 OR TerritoryID = 6;

/*7*/
SELECT ProductID, Name, Color
FROM Production.Product
WHERE Color != 'Blue' OR Color IS NULL;

/*8*/
SELECT BusinessEntityID, LastName, FirstName, MiddleName
FROM Person.Person
/* same*/
ORDER BY LastName, FirstName, MiddleName;

/*9*/
SELECT AddressLine1 + '(' +City+ ' ' +PostalCode+ ')'
FROM Person.Address;

/*10*/
SELECT ProductID, ISNULL(Color,'No Color') AS Color, Name
From Production.Product;

/*11*/
SELECT ProductID, Name + ISNULL(':'+ Color,'') AS Description
From Production.Product;

/*12*/
SELECT SpecialOfferID, Description, MinQty, MaxQty, (MaxQty - MinQty) AS Difference
FROM Sales.SpecialOffer;

/*13*/
SELECT SpecialOfferID, Description,ISNULL(MaxQty,10) * DiscountPct AS Discount
FROM Sales.SpecialOffer;

/*14*/
SELECT LEFT(AddressLine1,10) AS Address10
FROM Person.Address;

/*15*/
SELECT SalesOrderID, OrderDate, ShipDate, DATEDIFF(d,OrderDate,ShipDate) AS Difference
FROM Sales.SalesOrderHeader;

/*16*/
SELECT CONVERT(varchar,OrderDate,1) AS OrderDate, CONVERT(varchar,ShipDate,1) AS ShipDate
FROM Sales.SalesOrderHeader;

/*17*/
SELECT DateAdd(m,6,OrderDate) AS OrderDate6, ShipDate, OrderDate 
FROM Sales.SalesOrderHeader;

/*18*/
SELECT SalesOrderID, OrderDate, YEAR(OrderDate) AS OrderYear, MONTH(OrderDate) AS OrderMonth
FROM Sales.SalesOrderHeader;

/*19*/
SELECT CAST(RAND() * 10 AS INT) + 1;

/*20*/
SELECT SalesOrderID, OrderDate
FROM Sales.SalesOrderHeader
WHERE YEAR(OrderDate)= 2011;

/*21*/
SELECT SalesOrderID, OrderDate
FROM Sales.SalesOrderHeader
Order BY MONTH(OrderDate), YEAR(OrderDate);

--DAY 3--

/*1*/
SELECT COUNT(CustomerID)
FROM Sales.Customer;

/*2*/
SELECT MIN(ListPrice) AS MinPrice, MAX(ListPrice) AS MaxPrice, AVG(ListPrice) AS AvgPrice
FROM Production.Product;

SELECT * FROM Sales.SalesOrderDetail

/*3*/
SELECT SUM(OrderQty) AS Total, ProductID
FROM Sales.SalesOrderDetail
GROUP BY ProductID;

/*4*/
SELECT COUNT(*) AS count, SalesOrderID
FROM Sales.SalesOrderDetail
GROUP BY SalesOrderID;

/*5*/
SELECT * FROM Production.Product
SELECT COUNT(*) AS count, ProductLine
FROM Production.Product
GROUP BY ProductLine;

SELECT * FROM Production.Product;
/*6*/
SELECT CustomerID, COUNT(*) AS Count, YEAR(OrderDate) AS Year
FROM Sales.SalesOrderHeader
GROUP BY CustomerID, YEAR(OrderDate);

/*7*/
SELECT SalesOrderID, SUM(LineTotal) AS Total
FROM Sales.SalesOrderDetail
GROUP BY SalesOrderID, LineTotal
HAVING SUM(LineTotal) > 1000;

/*8*/
SELECT COUNT(*) AS count, ProductModelID
FROM Production.Product
GROUP BY ProductModelID
HAVING COUNT(*) = 1;

/*9*/
SELECT * FROM Sales.SalesOrderDetail
SELECT * FROM Sales.SalesOrderHeader
SELECT * FROM Production.Product

SELECT SUM(OrderQty) AS SUM, sd.ProductID ,OrderDate
FROM Sales.SalesOrderDetail AS sd, Sales.SalesOrderHeader AS sh, Production.Product AS pd
WHERE sd.SalesOrderID= sh.SalesOrderID AND sd.ProductID= pd.ProductID
GROUP BY sd.ProductID, OrderDate;

/*10*/
SELECT * FROM HumanResources.vEmployeeDepartment

SELECT * FROM 
( SELECT FirstName, StartDate, DENSE_RANK() over (ORDER BY StartDate asc) AS Rank
FROM HumanResources.vEmployeeDepartment)dr
WHERE dr.Rank=3;

/*11*/
SELECT * FROM Sales.SalesOrderHeader

SELECT * FROM 
(SELECT DENSE_RANK() over (ORDER BY Sum desc) AS Rank, CustomerID, Sum
FROM
(
SELECT CustomerID, COUNT(SalesOrderID) AS Sum
FROM Sales.SalesOrderHeader 
GROUP BY CustomerID
)t1
)t2
WHERE t2.Rank=2;

/*12*/
SELECT * FROM
(SELECT ROW_NUMBER() OVER(PARTITION BY ProductSubcategoryID ORDER BY standardcost DESC) AS rownum,
COUNT(*) OVER(PARTITION BY ProductSubcategoryID) AS COUNT , 
ProductSubcategoryID, StandardCost
FROM Production.Product) t1 WHERE t1.rownum * 1.0 / t1.COUNT <= 0.25

--DAY 4--

/*1*/
SELECT JobTitle,FirstName,LastName
FROM HumanResources.Employee AS hr
INNER JOIN 
Person.Person AS p
ON hr.BusinessEntityID= p.BusinessEntityID;

/*2*/
SELECT CustomerID, StoreID, TerritoryID, FirstName, MiddleName, LastName
FROM Person.Person AS p
JOIN
Sales.Customer AS sc
ON p.BusinessEntityID = sc.PersonID;

/*3*/
SELECT SalesOrderID, SalesQuota, Bonus
FROM Sales.SalesOrderHeader AS sh
JOIN
Sales.SalesPerson AS ss
ON sh.SalesPersonID = ss.BusinessEntityID;

/*4*/
SELECT * FROM Production.ProductModel 
SELECT * FROM Production.Product

SELECT t1.color,t1.size,t2.catalogdescription 
FROM Production.product t1 
JOIN 
Production.ProductModel t2
ON t1.ProductModelID=t2.ProductModelID;

/*5*/
SELECT FirstName, MiddleName, LastName, ppr.name
FROM Sales.Customer AS sc,
Person.Person AS pp,
Sales.SalesOrderDetail AS sod,
Sales.SalesOrderHeader AS soh,
Production.Product AS ppr
WHERE sc.PersonID= pp.BusinessEntityID AND sc.CustomerID= soh.CustomerID AND soh.SalesOrderID= sod.SalesOrderID
AND sod.ProductID= ppr.ProductID;

/*6*/
SELECT SalesOrderID , ppt.ProductID , name
FROM Production.Product AS ppt
LEFT OUTER JOIN Sales.SalesOrderDetail AS ssd
ON ppt.ProductID = ssd.ProductID;

/*7*/
SELECT scr.CurrencyRateID, scr.AverageRate,SalesOrderID, psm.ShipBase
FROM Sales.SalesOrderHeader AS ssh
LEFT OUTER JOIN Sales.CurrencyRate AS scr
ON ssh.CurrencyRateID = scr.CurrencyRateID
LEFT OUTER JOIN Purchasing.ShipMethod AS psm
ON ssh.ShipMethodID = psm.ShipMethodID;

/*9*/
SELECT * FROM
(SELECT ROW_NUMBER() OVER (ORDER BY birthDate desc) AS RowNum,BusinessEntityID,BirthDate
FROM HumanResources.Employee)t1
WHERE t1.RowNum=1;

/*10*/
SELECT * INTO #temp1
FROM Production.Product
WHERE color in (SELECT [Color] = 'red' FROM Production.Product);
SELECT * FROM #temp1
/*OR*/
SELECT * INTO #temp2
FROM Production.Product
WHERE color = 'red';
SELECT * FROM #temp2






