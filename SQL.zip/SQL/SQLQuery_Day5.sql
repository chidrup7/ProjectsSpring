create table patient1
(
    PatientID int primary key,
    Patient_Name varchar(20)
)



create table PatientAddress1
(
    PatientID int foreign key references patient1(PatientID),
    Patient_Address varchar(50)
)



create procedure sp_patient1(@pid int, @pname varchar(20),@padd varchar(50))
as
if exists(select * from patient1 where PatientID=@pid)
    print 'duplicate PatientID could not insert'
else
begin
    insert into patient1 values(@pid, @pname)
    insert into PatientAddress1 values(@pid, @padd)
    print 'record inserted'
end
exec sp_patient1 123, 'Ram', 'HSR'
exec sp_patient1 234, 'Ravi','BDA'
exec sp_patient1 345, 'Ramesh', 'BTM'



select * from patient1
select * from patientAddress1

---2---


CREATE table #temp_passenger
(
    pID varchar(10),
    pName varchar(20),
    pGender varchar(6),
    pDob varchar(20)
)
GO

alter procedure sp_AddPassenger (@pstring varchar(100))
as
begin
INSERT INTO #temp_passenger(pName,pID,PGender,pDob)
    SELECT
     REVERSE(PARSENAME(REPLACE(REVERSE(@pstring), ',', '.'), 1)),
     REVERSE(PARSENAME(REPLACE(REVERSE(@pstring), ',', '.'), 2)),
     REVERSE(PARSENAME(REPLACE(REVERSE(@pstring), ',', '.'), 3)),
     REVERSE(PARSENAME(REPLACE(REVERSE(@pstring), ',', '.'), 4))
end

exec sp_AddPassenger 'Ravi Ram,001,Male,12-Jan-2009';

select * from #temp_passenger;




--3---
alter procedure sp_AddPassenger1(@pstring varchar(100))
as
begin
DECLARE @age int
DECLARE @dob date = convert(date,REVERSE(PARSENAME(REPLACE(REVERSE(@pstring), ',', '.'), 4)))
SELECT @age = DATEDIFF(YY,@dob,getdate());
    IF @age > 6 and @age < 90
    begin
    if exists (select * from #temp_passenger where pID =  REVERSE(PARSENAME(REPLACE(REVERSE(@pstring), ',', '.'), 2)) )
        begin
        print 'ID already exisits';
        end
    else
        begin
        INSERT INTO #temp_passenger(pName,pID,PGender,pDob)
        SELECT
        REVERSE(PARSENAME(REPLACE(REVERSE(@pstring), ',', '.'), 1)),
        REVERSE(PARSENAME(REPLACE(REVERSE(@pstring), ',', '.'), 2)),
        REVERSE(PARSENAME(REPLACE(REVERSE(@pstring), ',', '.'), 3)),
        REVERSE(PARSENAME(REPLACE(REVERSE(@pstring), ',', '.'), 4))
        print 'Added Succesfullly'
        end
    end
    else
    print 'Non-Elgiblbe Age';
    end




sp_AddPassenger1 'cofe candhu,002,Male,12-Jan-1999';
sp_AddPassenger1 'Tom Jerry,003,Male,12-Jan-2009';



select * from #temp_passenger;