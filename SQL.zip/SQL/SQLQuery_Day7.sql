---1---

use citiusdb;



create or alter procedure strint @inputString varchar(30)
as
begin try
declare @rst int
--@result = CAST(@inputString as int)
set @rst = CONVERT(int, @inputString)



DECLARE @Counter INT
SET @Counter=1
WHILE ( @Counter <= @rst)
BEGIN
    PRINT 'Chidrup'
    SET @Counter  = @Counter  + 1
END



end try
begin catch
print 'The Input string must be a number!!'
end catch



exec strint '10'

---2---

create table #employees1
(
    id int identity(1,1),
    salary int
)



create procedure checkSalary1(@sal int)
as
begin try
if @sal <= 10000
raiserror('Salary must not be below 10000',16,1)
else
begin
    insert into #employees1 values (@sal)
    PRINT 'SALARY INSERTED'
    SELECT * FROM #employees1
end
end try
begin catch
    select
    ERROR_MESSAGE() as [ErrMsg],
    ERROR_LINE() as [LineNum]
end catch



exec checkSalary1 4000

---3---

use AdventureWorks2019;



select * from Production.Product



create table #costlypro
(
    PrName varchar(50),
    PrCost int
)



declare showCostly cursor
for
SELECT TOP (10)
P.Name , P.StandardCost
FROM Production.Product P
ORDER BY P.StandardCost DESC;
declare @pname varchar(20),@pc int
open showCostly
fetch next from showCostly into @pname,@pc
while @@FETCH_STATUS = 0
    begin
        insert into #costlypro values (@pname,@pc)
        fetch next from showCostly into @pname , @pc
    end
select * from #costlypro
close showCostly
deallocate showCostly

---4---

--A deadlock occurs when two (or more) processes lock the separate resource. Under these circumstances, each process cannot
--continue and begins to wait for others to release the resource. The only way to resolve a SQL Server deadlock is to terminate
--one of the processes and free up the locked resource so the process can complete.
--This occurs automatically when SQL Server detects a deadlock and kills off one of the competing processes