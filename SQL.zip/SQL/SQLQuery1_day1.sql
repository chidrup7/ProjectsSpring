
create database SP

create table Product
(
ProductID int primary key,
ProductName varchar(100),
ProductCost int,
QuantityInStock int,
ProductSubCategoryID int
)

create table SalesOrderDetail
(
SalesOrderDetailID int primary key,
SalesOrderHeaderID int,
ProductID int,
OrderQuantity int
)

create table SalesOrderHeader
(
SalesOrderHeaderID int primary key
OrderDate int,
CustomerID int,
SalesPersonID int
)

create table ProductSubCategory
(
ProductSubCategoryID int primary key
ProductSubCategoryName int,
ProductCategoryID int
)

create table ProductCategory
(
ProductCategoryID int primary key
ProductCategoryName int
)

create table employee
(
EmployeeID int primary key ,
Designation varchar(200),
ManagerID int,
DateOfJoining int,
DepartmentID int,
PersonID int
)

create table Department
(
DepartmentID int primary key,
DepartmentName varchar(200)
)
create table customer
(
customerID int primary key,
PersonID int,
TerritoryID int,
customerGrade varchar,
)

create table Territory
(
    TerritoryID int primary key,
    TerritoryName varchar(20),
    CountryID int
)
create table Country
(
    CountryID int primary key,
    CountryName varchar(20)
)
create table Person
(
    PersonID int primary key,
    Title varchar(50),
    FirstName varchar(20),
    MiddleName varchar(20),
    LastName varchar(20),
    Gender varchar(10),
    ModifiedData varchar(50)
)

select * from Product