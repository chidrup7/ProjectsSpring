select * from HumanResources.Employee
select * from Person.Person
select * from Sales.Customer
select * from Sales.SalesOrderHeader
select * from Sales. SalesPerson
select * from Production.ProductModel
select * from Production.Product
select * from Sales.SalesOrderDetail
select * from Sales.SalesOrderHeader
select * from Sales.CurrencyRate
select * from Purchasing.ShipMethod

---1---
select JobTitle, BirthDate, FirstName, LastName
from HumanResources.Employee as hr , Person.Person as pp
where hr.BusinessEntityID = pp.BusinessEntityID

---2---
select CustomerID, StoreID,  TerritoryID, FirstName, LastName 
from Person.Person as pp , Sales.Customer as sc
where pp.BusinessEntityID = sc.PersonID

---3---

select SalesOrderID, SalesQuota , Bonus 
from Sales.SalesOrderHeader as sso , Sales. SalesPerson as ssp
where ssp.BusinessEntityID = sso.SalesPersonID

---4---
select ppm.name,color,size, ppm.CatalogDescription
from Production.ProductModel as ppm , Production.Product as ppt
where ppm.ProductModelID = ppt.ProductID

---5---

select firstname,middlename, lastname, ppt.name
FROM Sales.Customer as sc,Person.Person as pp,Sales.SalesOrderDetail as ssd,Sales.SalesOrderHeader as ssh,Production.Product as ppt
where sc.PersonID = pp.BusinessEntityID and sc.CustomerID = ssh.CustomerID
and ssh.SalesOrderID = ssd.SalesOrderID and ssd.ProductID = ppt.ProductID

---6---
select SalesOrderID , ppt.ProductID , name
from Production.Product as ppt
left outer join Sales.SalesOrderDetail as ssd
on ppt.ProductID = ssd.ProductID

---7---
select scr.CurrencyRateID, scr.AverageRate,SalesOrderID, psm.ShipBase
from Sales.SalesOrderHeader as ssh
left outer join Sales.CurrencyRate as scr
on ssh.CurrencyRateID = scr.CurrencyRateID
left outer join Purchasing.ShipMethod as psm
on ssh.ShipMethodID = psm.ShipMethodID

---8---


---9---
select firstname,middlename,lastname,businessentityid as businessentityid,birthdate
from
(select firstname, lastname, middlename, pp.businessentityid, birthdate
from humanresources.employee as hre
inner join person.person as pp on pp.businessentityid = hre.businessentityid) a
where [birthdate] = (select max([birthdate]) from humanresources.employee)



---10---
SELECT * INTO #temp FROM Production.Product WHERE color in (SELECT [Color] = 'red' FROM Production.Product)
SELECT * FROM #temp
