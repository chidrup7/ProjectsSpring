create table test1
(
encode int primary key,
ename varchar(20),
salary int check(salary>=20000 and salary<=50000),
gender char(1) check(gender ='M' or gender ='F'),
deptid int check(deptid in(201,202,205))
)
insert into test values(101,'ravi',30000,'M',201)

select * from test
-------------------------------------------
--unique
create table test3
(
ecode int primary key,
emailid varchar(25) unique,
phno char(10) unique
)
insert into test3 values (101,'chdi@gmail.com',1234567898)
select * from test3

--------------------------------------------
----default

drop table test3
create table test3
(
encode int primary key,
salary int default 10000
)
insert into test3(encode) values(101)

insert into test3 values(101 , 25000)

select *from test3

-------------------
--not null/null
drop table test3
create table test3
(
ecode int primary key,
ename varchar(20) not null,
salary int not null
)
insert into test3 values(101,'chari',10000)

select *from test3

--------------------------------------------
--foreign key
create table dept2
(
deptid int primary key,
dname varchar(20),
id int
)
create table emp2
(
ecode int primary key,
ename varchar(20),
salary id,
deptid int references dept2(deptid)
)
insert into dept2 values (201, 'Ravi', 1000)

insert into emp2 values (102, 'Ravi', 1000,201)
insert into emp2 values (103, 'Rav', 1000,201)
insert into emp2 values (104, 'Ram', 1000,201)
insert into emp2 values (105, 'Rak', 1000,201)

select *from dept2
select *from emp2

-----------------------------------------------------------------

-----altering the table
alter table test add deptid1 int

alter table test drop column deptid1

--increase or decrease the size of the tabel
alter table test alter column ename varchar(25)

--renaming an existing column
sp_rename 'ename','empname'

---add primary key
create table nonn
(
encode int,
ename varchar(20)
)
alter table nonn alter column encode int not null
alter table nonn add constraint PK primary key(encode)

----droping an existing constaints

alter table nonn drop constraint PK

sp_help test
select *from test

--idintity columns-not allow user to supply the values. database will automatically put the value based on send value.

drop table test3
create table test3
(
encode int primary key identity(1,3),
ename varchar (10)
)
insert into test3 values('bbb')
insert into test3 values('ccc')
insert into test3 values('ddd')

select *from test3

---operations in sql
---relational operators : <,<=,>,>=,<>,!=,=
---

----like operator uses two character for pattern matching :
--1) %------> to replace multipe characters 
--2) underscore(_)-----> to replace singlr char

select *from emp2

insert into emp2 values (102, 'Ravi', 1000,201)
insert into emp2 values (103, 'Rav', 2000,201)
insert into emp2 values (104, 'Ram', 3000,201)
insert into emp2 values (105, 'Rak', 4000,201)

select * from emp2 where ename like 'R__'

select * from emp2 where ename like '%%v%'

------ordering records---
select * from emp2 order by salary desc,ecod desc --- then by sorting

--aliasing columns names 
select ecode as EmpCode , ename as EmpName , salary , deptid from emp

-------in built functions---
---a) Number/Math function
select SQRT(16), log10(10), sin(90), cos(90)

select POWER(2,3)
select round(11.86,0), CEILING(11.35), floor(11.76)

----string length ---
select LEN('welcome')
select left('welcome',3),right('welcome',3),SUBSTRING('welcome',2,3)
select upper('welcome'), lower('welcome')
select 'welcome' + space(10)+ 'to India'
select replace('india', 'in','In')
select concat('hello','how','are','u?')
select CHARINDEX('e','welcome')
select LTRIM('     welcome'),RTRIM('welcome     '),TRIM('     welcome    ')

-----date functions------

------to get the server date and time ----
select getdate()

--extracting parts of date and time--
select year(getdate()),month(getdate()),day(getdate())

select DATEPART(HH,getdate()) as [Hours],
DATEPART(MM,getdate()) as [Minutes],
DATEPART(SS,getdate()) as Seconds,
DATEPART(YYYY,getdate()) as [Year],
DATEPART(MM,getdate()) as [Month],
DATEPART(DD,getdate()) as [Day]

------adding and subracting two date parts------
select DATEADD("YY",2,getdate()),
DATEADD("MM",2,getdate())

select DATEDIFF("DD",getdate(),'2022-09-22')

select convert(varchar(25),getdate(),99) as "99"
select convert(varchar(25),getdate(),100) as "100"

create schema production
create schema humanresources
create schema sales
create schema person

---------------------------------------------------

--Aggregate commands----

select sum(salary) as TotalSal,
avg(salary) as AvgSal,
max(salary) as MaxSal,
min(salary) as MinSal,
count(salary) as N0Ofemps
from emp2


select * from emp2
select * from dept2
select upper(ename) from emp2

select sum(salary) as TotalSal,
avg(isnull(salary,0)) as AvgSal,
max(salary) as MaxSal,
min(salary) as MinSal,
count(isnull(salary,0)) as N0Ofemps
from emp2
group deptid

insert into dept2 values (201, 'Ravi', 1000)
insert into dept2 values (201, 'Ram', 1003)
insert into dept2 values (201, 'Raw', 1002)
insert into dept2 values (201, 'Rame', 1001)
--
create table employ
(
sname varchar(20),
id int,
salary int
)

select * from employ
where sname like '%m%'

insert into employ values('ram',10,10000)
insert into employ values('ravi',20,20000)
insert into employ values('ramesh',40,30000)
insert into employ values('rakesh',50,40000)
insert into employ values('ramnath',30,50000)


select avg(salary) as avgsalary
from employ

---------top N analysis---
select top 3 *from employ

select top 3 salary 
from employ
order by salary desc

select ROW_NUMBER() over(order by salary) as RowNum, *from employ

select RANK() over(partition by salary order by id desc) as Ranks , *from employ

select DENSE_RANK() over (partition by id  order by salary ) as RowNum ,* from employ

------Derived Tables-----

select id ,totalSal,maxsal,minsal,(maxsal-minsal) as [Max-Min]
from
(select id,sum(salary) as totalSal , max(salary) as MaxSal, min(salary) as MinSal
from employ
group by id) t1
where t1.totalSal<60000
order by t1.MaxSal

----temporary table:
--local temporary table:
create table #table_tbl_local
(
encode int,
ename varchar(20),
salary int
)

insert into #table_tbl_local values(101,'ram',1234)
select * from #table_tbl_local

-------global temporary table---
create table ##global_tbl
(
encode int,
ename varchar(20),
salary int
)

----sequence---

create sequence order_seq
as int 
start with 10
increment by 1

select *from employ
insert into employ values(next value for order_seq ,'sam', 15,12300)

create table orders 
(
orderid int default(next value for order_seq),
amount int,
date_of_tarns date
)
insert into orders(amount,date_of_tarns) values(20000, GETDATE())
insert into orders(amount,date_of_tarns) values(40000, GETDATE())
insert into orders(amount,date_of_tarns) values(50000, GETDATE())

select * from orders
select * from(
select ROW_NUMBER() over(order by totaldue desc) as RowNum,CustomerID,TotalDue
from [Sales].[SalesOrderHeader]) t1
where t1.RowNum=2

---subquery : nested query within a query

--find th eemployees working in the envienment in the department id of the employee whose ecode is 102

select *
from employ
where id=10

----Q3--
select *
from employ
where salary > (select avg(salary)
from employ)

--single row subquery
--multi rows subquery:-
--when the inner query gives more than one result. we should not use single valued operators. instead we should use 
---multi-valued operators

--i) IN :- compares with either of the result
--ii)ANY:- >ANY,<ANY
--iii)ALL:- >ALL,<ALL

--Single-column subquery
--Multi-column subquery

select *
from students
where fname=(select fname from tb11 where 1) and lname(select )

----correlated subquery---
--this is a subquery which refers the parent query record to get the value and execute its query

--Set operation--
--a) Union
--b) Intersect
--C) minus
--a)
select * 
from employ
where id=10
union all
select *
from employ
where id=20

--b)
select * 
from employ
--where id=10
intersect 
select *
from employ
where id=20

----Joins---
--these are the queries used for joining records which are scattered in multiple tables to avoid redundancy
--types:
--1) Unconditional or cross
---2) Inner join
select *from employ
select *from dept2
select *
from employ e
join dept2 d
on(e.id=d.id)
select *
from employ e, dept2 d
where e.id=d.id

--3) outer join
--i)Left outer join
--ii)Right outer join
--iii)Full outer join
--iv)Self-join

select e.code, e.ename
-------------------------------------
--Synonymns--

create synonym syn_emp for citiusdb.dbo.emp
select * from

select * from sys.synonyms

-----views------
--these are the database objects that store a select statment using tables
-- it is used to give access to only relevent data to end users instead of providing all the data
-- views do nt cache data out of query result used in the view.
--views are resolved dynamically
--views follow all the constraints as per its base table(s)

create view v1
as 
select id , salary
from employ

--------calling a view in selected 
select * from v1

---types 
--a) Simple view:uing only one table in its query
--b) join view:involve join query in its select statement

select *from employ
insert into v1 values(70,12300)


delete from v1 where id=70
select * from dept2
insert into dept2 values (200 , 'ram', 2000)
insert into dept2 values (300 , 'ramm', 3000)
insert into dept2 values (400 , 'raam', 4000)
insert into dept2 values (500 , 'rram', 5000)

create view join_v2
as 
select e.id,e.salary,e.sname,d.deptid,d.dname,d.dhead
from employ e
join dept2 d
on(e.id=d.deptid)

select *from join_v2

---T-SQL----

declare @x int,@y int=200
--assign value to a variable
set @x=100
select @x=100
--accessing the variable
select @x as X,@y as Y
print 'X=' + convert(char(5),@x) + ',Y=' + convert(char(5),@y)

--Q.declare and assign a salary and calculate the bonus. bonus is 10% of salary if it is above 5000 else 20%

--create procedure sp_calbonus
alter procedure sp_calbonus(@salary int)
as
declare   @bonus numeric(10,2)

--select @salary = 4000
if @salary>5000
begin
set @bonus=0.1*@salary
end
else
begin
set @bonus=0.2*@salary
end

select @salary as Salary, @bonus as Bonus

print @bonus

---calling a stored procedure ---

exec sp_calbonus 4000

--Q. create a stored procedure which accepts employee code and display bonus and salary of the employee assuming 10% 
---bonus if salary is above 5000 else 20%

create procedure sp_getempbonus1(@ec int)
as
declare @salary int, @bonus as numeric(10,2)
--get the salary of the employee from table
select @salary = salary from employ where id = @ec

if @salary>5000
select @bonus=0.1*@salary
else 

select @bonus = 0.2*@salary
---dispaly the salary , bonus, ecode 
select @ec as Ecode , @salary as salary , @bonus as bonus

exec sp_getempbonus1 101

--if-else --

--while---
declare @n int , @i int, @p int, @str varchar(100)=''
select @n=2, @i=1 
while @i<=10
begin

set @p=@n*@i
select @str=@str+convert(char(3),@p)+char(13)

set @i=@i+1
end
print @str

---Q3

create procedure sp_addemprecord(@ec int , @en varchar(10), @sal int , @did int)
as 
if exists (select * from employ where id=@ec)
print 'duplicate id, could not insert '
else 
begin
insert into employ values(@ec , @en, @sal, @did)
print 'Record inserted '
end
exec sp_addemprecord 120 ,'ravi', 12112, 201

---Advanage of stored procedure--
--1)Stored procedure are pre-comlied so its faster,hence
--response is quicker
--2)you can avoid repeating the code again and again so redundant
--coding is avoided
--3)since sp codes are stored is database, it can be shared
--across multiple client application
--4)U can group ur logically related sql statement into one single
--stored procedure
--5)In case of modification, it is centrally modified in the data
--base and it reflects to all consumers.



-------CASE STATEMENT ----------



---SYNTAX->
--Using case condition
declare @sal int,@bonus int
set @sal=6000
set @bonus=case
            when @sal between 10000 and 30000 then 0.1*@sal
            when @sal between 30001 and 50000 then 0.2*@sal
            when @sal between 50001 and 80000 then 0.3*@sal
            else 0
        end
        select @sal as salary,@bonus as bonus



--syntax2:case expression
declare @sal int,@did int,@bonus int
set @sal =60000
set @did=201
set @bonus=case @did
                when 201 then @sal*0.1
                when 202 then @sal*0.2
                when 203 then @sal*0.3
                else 0
            end
select @sal as salary,@did as Deptid,@bonus as Bonus
select * from emp
-----------------------------

alter procedure sp_child(@x int output )
as
set @x=@x +10
select @x as [Inside child SP]

alter procedure sp_parent
as
declare @x int 
set @x=100
select @x as [Before sending to child]
exec sp_child @x output
select @x as [After executing the child SP]

exec sp_parent 

---User defined functions---
--these are also like stored procedure having set of sql statements and programming construct 
--but unlike SP functions return a value.
--Based on the return type , function are categorised "
--a) Scalar -valued functions : it returns scalar data typed of value i.e., int , char , varchar, date , decimal, numeric and so on
--
--b)Table-Valued functions: It return TABLE TYPE of value which will a select result

create function fn_getbonus(@sal int) returns int 
as
begin
declare @bonus int
if @sal>5000
set @bonus=0.1*@sal
else 
set @bonus=0.2*@sal
return @bonus
end
select *, dbo.fn_getbonus(salary) as bonus from emp

---calling function in sp or fn---
declare @sal int=7000, @bonus int
set @bonus=dbo.fn_getbonus(@sal)
select @sal as Salary,@bonus as bonus

TABLE -VALUED function , retunr TABLE TYPE
--Table valued functions has suncategory
--i)inline table valued function--
--it juust uses a return statenent only return 
--no any other statements like declaratios or consructs are allow
--
create function fn_getempbydid(@did int)returns table
as
return 
(select *
from employ
where id=@did)

select *from dho.fn_getempbydid(202)

---Multi statements table valued functions

create function fn_getemps() returns @emps TABLE(@ecode int,@ename varchar (20))
as 
begin
insert into @emps select ecode , ename from emp where deptid = 202
end

select * from dbo.getemp

---Triggers---

--These are also like T-sql block of statements like SP etc but it is called automatically on some events or objects
--two types :
--1)Database trigger- DDL
--2)DML trigger

---DDL triggers 
create trigger trg2 on database
for Drop_TABLE
as
rollback tran
print ' u cannot drop table in this database, contact admin'

create table abcd
(
encode int,
ename varchar(20)
)

--DML triggers--

create trigger trg3
on employ
for insert
as
print 'trigger fired , record inserted'

insert into employ values( 'sam', 17, 30405)

select * from employ

drop trigger trg2 on database

create table tb1_log
(
ecode int,
ename varchar(20),
salary int,
depit int,
date_of_tran datetime
)
create trigger del_trig
on employ
for delete
as
declare @ec int , @en varchar(20), @sal int, @did int
--get the detailed record values from deleted table

select @ec=ecod,@en=ename,@sal=salary,@did=deptid from deleted
--log into log table i.e., insert the record 
insert into tbl_log values(2ec,@en,@sal,@did,getdate())
print 'record deleted'


---------------------------------------
--error-----



--transaction-----
--it is a group of related sql statement which are executed as one single unit of task.
--that means all the statements should finish totally and incase if any if them fails previous statements also must be rolled back.

--a) implicit transaction : for all the sql DML operations statements , sql server automatically begins a transaction and commits it automatically
--b) explicit transaction : these transaction needs to initiated and finished by the user .
--note : A transaction always finishes either with commit (success) or rollback(failed).

-- when there are multiple transaction running in database there are chances of loss of data , inconsistency of data, phanton
--read/write, dirty read due to concurrent access  of the data at the same time by multiple uders.

---this done with the help of transaction isolation defind by thr server 
--1) READ uncommited: this is the default isolation 
--2) Read committed :
--3) Repeatable Read:
--4) Serializable   :this isolation level is does not allow any of the operations INSERT , UPDATE OR SELECT while one one 
--transaction gets initiated in serial one after another .this more consistent data in database.
--5) Snapshot       : in this isolated level, the snapshot of the data provided user that means user is not working on 
--current state of data rather users carries snapshot of data when trans was started.

begin transaction
update employ set salary = salary+1020 where id=10

rollback tran

select * from employ where id=10

set transaction isolation level read committed
begin tran
select * from employ
------

--transactions can have savepoints
begin tran t1
--statement 1 &2
save tran t2
--statement 3&4
save tran t3
--statement 5&6
rollback tran t4

--usage example

exec sp_transdemo
alter procedure sp_transdemo
as 
begin try
begin tran
delete from employ where id=11
insert into employ values('sam' , 10, 101010)
commit tran
print 'transaction success , hence committed'
end try
begin catch
rollback tran
print 'fail'
end catch

select *from employ


---- indexes ----
--These are data base objects used to increase the performance of the queries . Indexes maintain the address of the record 
-- stored in the database , so when a query searches a record , it directly goes to the address of the record using index,
-- info.hence faster retrieving of records.

--types:
--1) Clustered index: in this the records are sorted first then index is created 
--2) Non-Clustered index : index with unsorted reccords.

---Index fill Factor ---

---page splitting---
--it is a process used by server to accomodate new records falling in between the data pages .when there is lot of frequent
--insert in the database then there is chance of page splitting hence reduces performance .
-- to reduce page splitting , we use fill factor parameter which keeps some reserved space for new records in all data pages.

create index idx4
on employ(sname)
with fillfactor=5,
pad_index on


---syntax--
alter index idx4 on employ
reorganize
----
alter index idx4 on employ ---when more fragmentation is there
rebuild

Database performance tuning wizard:-

--Database excution plan in sql-
--a)Actual excution plan
--b)Etimated excution plan

select *from employ where id=10

----pivot operator----
--it is used for display the result in cross-tab format.
--rows values gets displayed as columns.


select *from employ

select id, sum(salary) as total
from employ
group by id

select [10],[20],[30]
from (select id, salary from employ) dv
pivot(
sum(salary) for id in ([10],[20],[30])
) as pvt


-------------
--SQL Coding Guidelines--

--1) Write proper comments in your TSQL scripts like stored procedures, triggers.
--2) Table should have optimum normalization. Atleast 3rd normal form should be there.
--3) Proper naming convections for database, tables, views and other objects. TSQL variables also must have proper naming
--convections.
--4) Never use in the query SELECT * from tbale as it increases IO. Rather use selected columns SELECT empid, name from employees
--5)proper indexing should be done
--6)use SET NOCOUNT OFF towards the start of ur SQL statments
--7)try using derived tables compared to temporary tables.
--8) try to use stored procedures from the client applications for your quries i.e., INSERT , DELETE , UPDATE statements.
     --It keeps the db information abstracted from clients 
--10)Try to give constraints name by urself instead of giving server to provide ename

create table xyz1
(
id int,
sname varchar(25)
constraint pk1 primary key(id)
)

---Normalization---
--it is a process of removing redundancy of data in database .
--1NF : A table is in 1NF only if there are no repeating 
--groups of the same type or values in a same column are not stored with comman separated values.
--2NF : A table is in 2nf only if it is in 1nf and there is no partial dependencies in the table.
