---1---

--Document your understanding on Query plan.

--A query plan (or query execution plan) is a sequence of steps used to access data in a SQL relational database management system.
--This is a specific case of the relational model concept of access plans. A given database management system may offer one or more mechanisms for returning the plan for a given query.
--Some packages feature tools which will generate a graphical representation of a query plan. Other tools allow a special mode to be set on the connection to cause the DBMS to return a textual description of the query plan.
--Another mechanism for retrieving the query plan involves querying a virtual database table after executing the query to be examined.


---2---

--Document your understanding on different types of Scans while reading from a table.

--Table scan:
--A table scan is a straightforward process. When your query engine performs a table scan it starts from the physical beginning of the table and goes through every row in the table.
--If a row matches the criterion, then it includes that into the result set. n a small table, a query engine can load all data in just one shot but in a large table,
--it's not possible, which means more IO and more time to process those data.
--Normally, a full table scan is used when your query doesn't have a WHERE clause.



--Index scan:
--If your table has a clustered index and you are firing a query that needs all or most of the rows i.e. query without WHERE or HAVING clause, then it uses an index scan.
--It works similar as the table scan, during the query optimization process, the query optimizer takes a look at the available index and chooses the best one,
--based on information provided in your joins and where clause, along with the statistical information database keeps.
--Once the right index is chosen, the SQL Query processor or engine navigates the tree structure to the point of data that matches your criteria and again extracts only the records it needs.



--Index seek:
--When your search criterion matches an index well enough that the index can navigate directly to a particular point in your data, that's called an index seek.
--It is the fastest way to retrieve data in a database. The index seeks are also a great sign that your indexes are being properly used.
--This happens when you specify a condition in WHERE clause like searching an employee by id or name if you have a respective index.


---3---

CREATE TABLE SalesPerson
(
Name varchar(20),
Year int,
Sales int
);



INSERT INTO SalesPerson VALUES('SAM',2010,20000)
INSERT INTO SalesPerson VALUES('JOHN',2010,30000)
INSERT INTO SalesPerson VALUES('JOHN',2010,15000)
INSERT INTO SalesPerson VALUES('SAM',2011,70000)
INSERT INTO SalesPerson VALUES('JOHN',2011,89000)
INSERT INTO SalesPerson VALUES('SAM',2011,12000)



SELECT *FROM SalesPerson



SELECT *
FROM (  SELECT [Year],[Name],[Sales]
        FROM SalesPerson) MT
PIVOT (SUM([Sales]) FOR [Name] IN ([SAM],[JOHN])) HM
drop table SalesPerson

---4---

--a. Tables

--Good Practices

--� Use Simple, Descriptive Column Names

--� Use Simple, Descriptive Table Names

--� Have an Integer Primary Key

--� Be Consistent with Foreign Keys

--� Store Datetimes as Datetimes



--Bad Practices

--� Ignoring the Purpose of the Data

--� Poor Naming Conventions

--� NULLs and the NOT IN predicate

--� Multiple Pieces of Information in a Single Field

--� Using Spaces or Quotes in Table Names



--b. Joins

--Good Practices

--� Use the JOIN and ON Keywords

--� Choose Appropriate SQL JOIN Type.

--� Carefully Design the JOIN Condition.

--� Use Table Aliases.

--� Use Column Aliases.

--� Knowing Different Joins Before Using Them

--Bad Practices

--� Using multiple joins

--� using joins includes that they are not as easy to read

--� Joins cannot be avoided when retrieving data from a normalized database



--c. Indexes

--Good Practices

--� Use the WHERE Clause

--� Use Datatypes Efficiently

--� Know when Indexes are not Used

--� Build indexes based on predicates

--� Understand how database design impacts SQL Server indexes

--Bad Practices

--� Indexing every column

--� indexing data that you need to look up

--� Doing Over-index and Doing Under-index

--� Not Using data sort order

------------