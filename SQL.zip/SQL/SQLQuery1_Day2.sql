select * from Person.Person

--1
SELECT BusinessEntityID, FirstName, MiddleName, LastName, ModifiedDate
FROM Person.Person
WHERE ModifiedDate > '2000-12-29';

---2
SELECT BusinessEntityID, FirstName, MiddleName, LastName, ModifiedDate
FROM Person.Person
WHERE ModifiedDate BETWEEN '2000-12-01' AND '2000-12-31';

--3

SELECT ProductID, Name
FROM Production.Product
WHERE Name LIKE 'Chain%'; 

--4
SELECT BusinessEntityID, FirstName, MiddleName, LastName
FROM Person.Person
WHERE MiddleName LIKE '[E,B]';

--5
SELECT SalesOrderID, OrderDate, TotalDue
FROM Sales.SalesOrderHeader
WHERE OrderDate BETWEEN '2001-09-01' AND '2001-09-30'
 AND TotalDue > 1000;

--6
SELECT SalesOrderID, OrderDate, TotalDue, SalesPersonID, TerritoryID
FROM Sales.SalesOrderHeader
WHERE TotalDue > 1000 AND (SalesPersonID = 279 OR TerritoryID = 6);

--7
SELECT ProductID, Name, Color
FROM Production.Product
WHERE Color IS NULL OR Color <> 'Blue';

--8
SELECT BusinessEntityID, LastName, FirstName, MiddleName
FROM Person.Person
ORDER BY LastName, FirstName, MiddleName;

--9
SELECT AddressLine1 + ' (' + City + ' ' + PostalCode + ')'
FROM Person.Address;
--select * from Person.Address

--10
SELECT ProductID, ISNULL(Color,'No Color') AS Color, Name
FROM Production.Product;
--select * from Production.Product

--11
SELECT ProductID, Name + ISNULL(': ' + Color,' ') AS Description
FROM Production.Product;

--12
SELECT SpecialOfferID, Description, MaxQty - MinQty AS Diff
FROM Sales.SpecialOffer; 
--select * from Sales.SpecialOffer

--13
SELECT SpecialOfferID, Description, ISNULL(MaxQty,10) * DiscountPct AS Discount
FROM Sales.SpecialOffer;

--14
SELECT LEFT(AddressLine1,10) AS Address10
FROM Person.Address; 

--15
SELECT SalesOrderID, OrderDate, ShipDate,
 DATEDIFF(d,OrderDate,ShipDate) AS NumberOfDays
FROM Sales.SalesOrderHeader;
--select * from Sales.SalesOrderHeader

--16
SELECT CONVERT(VARCHAR,OrderDate,1) AS OrderDate,
 CONVERT(VARCHAR, ShipDate,1) AS ShipDate
FROM Sales.SalesOrderHeader; 
--select * from Sales.SalesOrderHeader

--17
SELECT SalesOrderID, OrderDate, DATEADD(m,6,OrderDate) Plus6Months
FROM Sales.SalesOrderHeader; 

--18
SELECT SalesOrderID, OrderDate, YEAR(OrderDate) AS OrderYear,
 MONTH(OrderDate) AS OrderMonth
FROM Sales.SalesOrderHeader;

--19
SELECT CAST(RAND() * 10 AS INT) + 1;

--20
SELECT SalesOrderID, OrderDate
FROM Sales.SalesOrderHeader
WHERE YEAR(OrderDate) = 2001; 

--21
SELECT SalesOrderID, OrderDate
FROM Sales.SalesOrderHeader
ORDER BY MONTH(OrderDate), YEAR(OrderDate);
select * from Sales.SalesOrderHeader
