package com.spring.exception;

public class ErrorDetails {

	String errormessage;
	int errorcode;
	
	
	public ErrorDetails() {
		super();
	}
	
	public ErrorDetails(String errormessage, int errorcode) {
		super();
		this.errormessage = errormessage;
		this.errorcode = errorcode;
	}

	public String getErrormessage() {
		return errormessage;
	}
	public void setErrormessage(String errormessage) {
		this.errormessage = errormessage;
	}
	public int getErrorcode() {
		return errorcode;
	}
	public void setErrorcode(int errorcode) {
		this.errorcode = errorcode;
	}

}
