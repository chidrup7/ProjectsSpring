package com.spring.exception;

public class ClassNotfoundException extends RuntimeException {

	public ClassNotfoundException(String message) {
		super(message);
	}

}
