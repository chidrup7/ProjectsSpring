package com.spring.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import com.spring.model.Flight;

public interface FlightService {
	
	public void addflight(Flight flight);
	public void deleteFlightById(int id);
	public List<Flight> getAllFlights();
	public Optional<Flight> getFlightById(int id);
	public void updateFlight(int id, Flight flight);
	public List<Flight> findBySourceDestinationDate(String source, String destination, Date date);
	

}
