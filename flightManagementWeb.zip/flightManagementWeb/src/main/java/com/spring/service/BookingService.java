package com.spring.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.spring.model.Booking;

public interface BookingService {
	
	public void addBooking(Booking booking);
	public void deleteBookingById(int id);
	public List<Booking> getAllBooking();
	public Optional<Booking> getBookingById(int id);
	public void updateBooking(int id, Booking booking);
	public Optional<Booking> getBookingByBookingDate(Date date);

}
