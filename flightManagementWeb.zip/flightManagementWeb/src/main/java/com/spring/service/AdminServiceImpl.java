package com.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.Customer;
import com.spring.model.Flight;
import com.spring.repository.CustomerRepository;
import com.spring.repository.FlightRepository;

@Service
public class AdminServiceImpl implements AdminService{
	
	@Autowired
	FlightRepository flightRepository;
	
	@Autowired
	CustomerRepository customerRepository;

	@Override
	public void addFlight(Flight flight) {
		flightRepository.save(flight);
		
	}

	@Override
	public void updateFlight(int id, Flight flight) {
		Flight f = flightRepository.findById(id).orElse(null);
		f.setFlightCapacity(flight.getFlightCapacity());
		f.setFlightDate(flight.getFlightDate());
		f.setFlightDestination(flight.getFlightDestination());
		f.setFlightDuration(flight.getFlightDuration());
		f.setFlightPrice(flight.getFlightPrice());
		f.setFlightSource(flight.getFlightSource());
		
		flightRepository.save(f);
	}

	@Override
	public void deleteFlight(int flightId) {
		flightRepository.deleteById(flightId);
		
	}

	@Override
	public List<Flight> getAllFlights() {
		List<Flight> flight = flightRepository.findAll();
		return flight;
		
	}

	@Override
	public List<Customer> getAllCustomers() {
		List<Customer> customer = customerRepository.findAll();
		return customer;
	}

}
