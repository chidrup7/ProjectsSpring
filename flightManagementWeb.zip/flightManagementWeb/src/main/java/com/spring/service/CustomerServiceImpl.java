package com.spring.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.spring.model.Customer;
import com.spring.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository customerRepository;

	@Override
	public void addCustomer(Customer customer) {
		customerRepository.save(customer);
		
	}

	@Override
	public void deleteCustomerById(int id) {
		customerRepository.deleteById(id);
		
	}

	@Override
	public List<Customer> getAllCustomer() {
	List<Customer> customer = customerRepository.findAll();
		return customer;
	}

	@Override
	public Optional<Customer> getCustomerById(int id) {
		return customerRepository.findById(id);
	}

	@Override
	public void updateCustomer(int id, Customer customer) {
		
		Customer customers = customerRepository.findById(id).orElse(null);
		customers.setCustomerName(customer.getCustomerName());
		customers.setCustomerUsername(customer.getCustomerUsername());
		customers.setCustomerPassword(customer.getCustomerPassword());
		customers.setCustomerEmail(customer.getCustomerEmail());
		customers.setCustomerPhone(customer.getCustomerPhone());
		
		customerRepository.save(customers);
		
	}

	@Override
    public List<Customer> findCustomersByFlightIdAndFlightDate(int flightId, Date flightDate) {
        List<Object[]> results = customerRepository.findCustomersByFlightIdAndFlightDate(flightId, flightDate);
        List<Customer> customers = new ArrayList<>();

        for (Object[] result : results) {
            Customer customer = new Customer();
            customer.setCustomerId((Integer) result[0]);
            customer.setCustomerPhone((Long) result[1]);
            customer.setCustomerName((String) result[2]);
            customer.setCustomerUsername((String) result[3]);
            
            customers.add(customer);
        }

        return customers;
    }

	


}
