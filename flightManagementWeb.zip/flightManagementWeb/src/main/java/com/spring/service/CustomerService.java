package com.spring.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.spring.model.Customer;


public interface CustomerService {

	public void addCustomer(Customer customer);
	public void deleteCustomerById(int id);
	public List<Customer> getAllCustomer();
	public Optional<Customer> getCustomerById(int id);
	public void updateCustomer(int id, Customer customer);
	
	public List<Customer> findCustomersByFlightIdAndFlightDate(int flightId, Date flightDate);
}
