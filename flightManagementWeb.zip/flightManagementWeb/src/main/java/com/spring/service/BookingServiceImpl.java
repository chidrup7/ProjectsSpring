package com.spring.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.spring.model.Booking;
import com.spring.repository.BookingRepository;

@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	BookingRepository bookingRepository;
	
	
	@Override
	public void addBooking(Booking booking) {
		bookingRepository.save(booking);
		
	}

	@Override
	public void deleteBookingById(int id) {
		bookingRepository.deleteById(id);
		
	}

	@Override
	public List<Booking> getAllBooking() {
		List<Booking> booking = bookingRepository.findAll();
		return booking;
	}

	@Override
	public Optional<Booking> getBookingById(int id) {
		return bookingRepository.findById(id);
	}

	@Override
	public void updateBooking(int id, Booking booking) {
		
		Booking bookings = bookingRepository.findById(id).orElse(null);
		bookings.setCustomer(booking.getCustomer());
		bookings.setFlight(booking.getFlight());
		bookings.setBookingAmount(booking.getBookingAmount());
		bookings.setSeatNumber(booking.getSeatNumber());
		
		bookingRepository.save(bookings);
		
		
	}
	
	

	
	public Optional<Booking> getBookingByBookingDate(Date date) {
		
		return bookingRepository.findBookingByBookingDate(date);
	}

}
