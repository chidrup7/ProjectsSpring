package com.spring.service;

import java.util.List;

import com.spring.model.Customer;
import com.spring.model.Flight;

public interface AdminService {

	public void addFlight(Flight flight);
	public void updateFlight(int flightId, Flight flight);
	public void deleteFlight(int flightId);
	public List<Flight> getAllFlights();
	public List<Customer> getAllCustomers();
}
