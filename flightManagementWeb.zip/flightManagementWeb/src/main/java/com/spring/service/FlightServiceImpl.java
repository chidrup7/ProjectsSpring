package com.spring.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.Flight;
import com.spring.repository.FlightRepository;

@Service
public class FlightServiceImpl implements FlightService {
	
	@Autowired
	FlightRepository flightRepository;

	@Override
	public void addflight(Flight flight) {
		flightRepository.save(flight);
		
	}

	@Override
	public void deleteFlightById(int id) {
		flightRepository.deleteById(id);
	}

	@Override
	public List<Flight> getAllFlights() {
		List<Flight> flight = flightRepository.findAll();
		return flight;
	}

	@Override
	public Optional<Flight> getFlightById(int id) {
		return flightRepository.findById(id);
		
	}

	@Override
	public void updateFlight(int id, Flight flight) {
		Flight flights = flightRepository.findById(id).orElse(null);
		flights.setFlightName(flight.getFlightName());
		flights.setFlightDate(flight.getFlightDate());
		flights.setFlightSource(flight.getFlightSource());
		flights.setFlightDestination(flight.getFlightDestination());
		flights.setFlightPrice(flight.getFlightPrice());
		flights.setFlightDuration(flight.getFlightDuration());
		flights.setFlightCapacity(flight.getFlightCapacity());
		
		flightRepository.save(flights);
		
	}

	@Override
	public List<Flight> findBySourceDestinationDate(String source, String destination, Date date) {
		return flightRepository.findByFlightSourceAndFlightDestinationAndFlightDate(source, destination, date);
	}

}
