package com.spring.controller;

import java.nio.file.Path;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.model.Customer;
import com.spring.service.CustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	CustomerService customerService;
	
	@PostMapping("/add")
	public void addCustomer(@RequestBody Customer customer) {
		customerService.addCustomer(customer);
	}
	
	
	@DeleteMapping("/delete")
	public void deleteCustomer(@PathVariable int id) throws ClassNotFoundException {
		if(customerService.getCustomerById(id).isPresent()) {
			customerService.deleteCustomerById(id);
		}else
			throw new ClassNotFoundException("Class Not Found");
	}
	@GetMapping("/customers")
	public List<Customer> getAllCustomer(){
		
		List<Customer> customer = customerService.getAllCustomer();
		return customer;
	}
	
	@GetMapping("/customer/{id}")
	public ResponseEntity<Customer> getCustomerById(@PathVariable("id") int id) throws ClassNotFoundException{
		 Optional<Customer> customer = customerService.getCustomerById(id);
			if(customer.isPresent()) {
				return ResponseEntity.ok(customer.get());
			}
			throw new ClassNotFoundException("Bookong not found");
	}
	
	@GetMapping("/{flight_id}/{flight_date}")
	public List<Customer> findCustomersByFlightIdAndFlightDate(@PathVariable("flight_id") int flight_id, @PathVariable("flight_date") @DateTimeFormat(pattern = "yyyy-MM-dd") Date flight_date){
		return customerService.findCustomersByFlightIdAndFlightDate(flight_id, flight_date);
	}
	
}
