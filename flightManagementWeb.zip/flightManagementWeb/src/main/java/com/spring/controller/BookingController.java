package com.spring.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.model.Booking;
import com.spring.repository.BookingRepository;
import com.spring.service.BookingService;


@RestController
@RequestMapping("/booking")
public class BookingController {

	@Autowired
	BookingService bookingService;
	
	@PostMapping("/add")
	public void addBooking(@RequestBody Booking booking) {
		bookingService.addBooking(booking);
	}
	
	@DeleteMapping("/delete")
	public void deleteBooking(@PathVariable int id) throws ClassNotFoundException {
		if(bookingService.getBookingById(id).isPresent()) {
			bookingService.deleteBookingById(id);
		}else
			throw new ClassNotFoundException("Class Not Found");
	}
	
	@GetMapping("/bookings")
	public List<Booking> getAllBooking(){
		
		List<Booking> booking = bookingService.getAllBooking();
		return booking;
	}
	
	@GetMapping("/booking/{id}")
	public ResponseEntity<Booking> getBookingById(@PathVariable("id") int id) throws ClassNotFoundException{
		 Optional<Booking> booking = bookingService.getBookingById(id);
			if(booking.isPresent()) {
				return ResponseEntity.ok(booking.get());
			}
			throw new ClassNotFoundException("Bookong not found");
	}
	
	@GetMapping("/{booking-date}")
	public ResponseEntity<Booking> getBookingByBookingDate(@PathVariable("booking-date") @DateTimeFormat(pattern = "yyyy-MM-dd") Date date)  throws ClassNotFoundException{
		Optional<Booking> booking = bookingService.getBookingByBookingDate(date);
		if(booking.isPresent()) {
			return ResponseEntity.ok(booking.get());
		}
		throw new ClassNotFoundException("Booking not found");
	}
}
