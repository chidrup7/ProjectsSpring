package com.spring.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.model.Customer;
import com.spring.model.Flight;
import com.spring.repository.FlightRepository;
import com.spring.service.FlightService;

@RestController
@RequestMapping("/flight")
public class FlightController {
	
	@Autowired
    private FlightService flightService;

    @GetMapping("/{source}/{destination}/{date}")
    public List<Flight> getFlightsBySourceDestinationDate(@PathVariable String source,
                                                          @PathVariable String destination,
                                                          @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") Date date) {
        return flightService.findBySourceDestinationDate(source, destination, date);
    }
    
    @PostMapping("/flight")
    public void addFlight(@RequestBody Flight flight) {
        flightService.addflight(flight);
    }
    
    @DeleteMapping("/delete")
	public void deleteFlight(@PathVariable int id) throws ClassNotFoundException {
		if(flightService.getFlightById(id).isPresent()) {
			flightService.deleteFlightById(id);
		}else
			throw new ClassNotFoundException("Class Not Found");
	}
	@GetMapping("/flights")
	public List<Flight> getAllFlights(){
		
		List<Flight> flight = flightService.getAllFlights();
		return flight;
	}
	
	@GetMapping("/flight/{id}")
	public ResponseEntity<Flight> getFlightById(@PathVariable("id") int id) throws ClassNotFoundException{
		 Optional<Flight> flight = flightService.getFlightById(id);
			if(flight.isPresent()) {
				return ResponseEntity.ok(flight.get());
			}
			throw new ClassNotFoundException("Bookong not found");
	}
	
	@PutMapping("/{flight_id}")
	public void updateFlight(@PathVariable("flight_id") int flight_id, @RequestBody Flight flight) {
		flightService.updateFlight(flight_id, flight);
	}
}
