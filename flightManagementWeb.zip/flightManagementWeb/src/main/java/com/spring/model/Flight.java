package com.spring.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Flight")
public class Flight {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int flightId;
    String flightName;
    Date flightDate;
    String flightSource;
    String flightDestination;
    float flightPrice;
    float flightDuration;
    int flightCapacity;

public Flight() {
	super();
}

public Flight(int flightId, String flightName, Date flightDate, String flightSource, String flightDestination,
		float flightPrice, float flightDuration, int flightCapacity) {
	super();
	this.flightId = flightId;
	this.flightName = flightName;
	this.flightDate = flightDate;
	this.flightSource = flightSource;
	this.flightDestination = flightDestination;
	this.flightPrice = flightPrice;
	this.flightDuration = flightDuration;
	this.flightCapacity = flightCapacity;
}

public int getFlightId() {
	return flightId;
}

public void setFlightId(int flightId) {
	this.flightId = flightId;
}

public String getFlightName() {
	return flightName;
}

public void setFlightName(String flightName) {
	this.flightName = flightName;
}

public Date getFlightDate() {
	return flightDate;
}

public void setFlightDate(Date flightDate) {
	this.flightDate = flightDate;
}

public String getFlightSource() {
	return flightSource;
}

public void setFlightSource(String flightSource) {
	this.flightSource = flightSource;
}

public String getFlightDestination() {
	return flightDestination;
}

public void setFlightDestination(String flightDestination) {
	this.flightDestination = flightDestination;
}

public float getFlightPrice() {
	return flightPrice;
}

public void setFlightPrice(float flightPrice) {
	this.flightPrice = flightPrice;
}

public float getFlightDuration() {
	return flightDuration;
}

public void setFlightDuration(float flightDuration) {
	this.flightDuration = flightDuration;
}

public int getFlightCapacity() {
	return flightCapacity;
}

public void setFlightCapacity(int flightCapacity) {
	this.flightCapacity = flightCapacity;
}

@Override
public String toString() {
	return "Flight [flightId=" + flightId + ", flightName=" + flightName + ", flightDate=" + flightDate
			+ ", flightSource=" + flightSource + ", flightDestination=" + flightDestination + ", flightPrice="
			+ flightPrice + ", flightDuration=" + flightDuration + ", flightCapacity=" + flightCapacity + "]";
}
    
    
    
	
	
	
}