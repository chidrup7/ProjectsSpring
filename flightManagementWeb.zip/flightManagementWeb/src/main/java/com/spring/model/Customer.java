package com.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Customer")

public class Customer {

	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int customerId;
    String customerName;
    String customerUsername;
    String customerPassword;
    String customerEmail;
    long customerPhone;




public Customer() {
	super();
}




public Customer(int customerId, String customerName, String customerUsername, String customerPassword,
		String customerEmail, long customerPhone) {
	super();
	this.customerId = customerId;
	this.customerName = customerName;
	this.customerUsername = customerUsername;
	this.customerPassword = customerPassword;
	this.customerEmail = customerEmail;
	this.customerPhone = customerPhone;
}




public int getCustomerId() {
	return customerId;
}




public void setCustomerId(int customerId) {
	this.customerId = customerId;
}




public String getCustomerName() {
	return customerName;
}




public void setCustomerName(String customerName) {
	this.customerName = customerName;
}




public String getCustomerUsername() {
	return customerUsername;
}




public void setCustomerUsername(String customerUsername) {
	this.customerUsername = customerUsername;
}




public String getCustomerPassword() {
	return customerPassword;
}




public void setCustomerPassword(String customerPassword) {
	this.customerPassword = customerPassword;
}




public String getCustomerEmail() {
	return customerEmail;
}




public void setCustomerEmail(String customerEmail) {
	this.customerEmail = customerEmail;
}




public long getCustomerPhone() {
	return customerPhone;
}




public void setCustomerPhone(long customerPhone) {
	this.customerPhone = customerPhone;
}




@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerUsername="
			+ customerUsername + ", customerPassword=" + customerPassword + ", customerEmail=" + customerEmail
			+ ", customerPhone=" + customerPhone + "]";
}
	
	
	
	
	
	
	
	
}
