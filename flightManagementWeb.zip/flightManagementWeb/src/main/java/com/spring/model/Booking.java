package com.spring.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
//import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Booking")
public class Booking {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int bookingId;
    @ManyToOne
    @JoinColumn(name = "customerId")
    private Customer customer;
    @ManyToOne
    @JoinColumn(name = "flightId")
    private Flight flight;
    private float bookingAmount;
    private int seatNumber;
    private Date bookingDate;

	public Booking() {
		super();
	}

	public Booking(int bookingId, Customer customer, Flight flight, float bookingAmount, int seatNumber,
			Date bookingDate) {
		super();
		this.bookingId = bookingId;
		this.customer = customer;
		this.flight = flight;
		this.bookingAmount = bookingAmount;
		this.seatNumber = seatNumber;
		this.bookingDate = bookingDate;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Flight getFlight() {
		return flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}

	public float getBookingAmount() {
		return bookingAmount;
	}

	public void setBookingAmount(float bookingAmount) {
		this.bookingAmount = bookingAmount;
	}

	public int getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}

	public Date getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", customer=" + customer + ", flight=" + flight + ", bookingAmount="
				+ bookingAmount + ", seatNumber=" + seatNumber + ", bookingDate=" + bookingDate + "]";
	}

	
	
}

