package com.spring.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.spring.model.Flight;

@Repository
public interface FlightRepository extends JpaRepository<Flight, Integer>{
	List<Flight> findByFlightSourceAndFlightDestinationAndFlightDate(String source, String destination, Date date);
}
