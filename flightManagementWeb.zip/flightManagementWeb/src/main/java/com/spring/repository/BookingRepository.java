package com.spring.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.spring.model.Booking;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Integer> {

	/*
	 * @Query(value
	 * ="select * from Booking b where b.bookingDate = (select booking_date from booking b where b.bookng_date= :bookingDate)"
	 * ,nativeQuery = true) Optional<Booking>
	 * findBookingByBookingDate(@Param("bookingDate") Date bookingDate);
	 */
	
	Optional<Booking> findBookingByBookingDate(Date bookingDate);
}
