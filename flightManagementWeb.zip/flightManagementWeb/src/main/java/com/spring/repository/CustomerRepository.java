package com.spring.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.spring.model.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer>{
	
	 @Query("select  c.customerId, c.customerPhone, c.customerName, c.customerUsername,f.flightId, f.flightDate from Customer c join Booking b on c.customerId = b.customer.customerId join Flight f on f.flightId = b.flight.flightId WHERE b.flight.flightId = :flightId AND f.flightDate = :flightDate")
	 List<Object[]> findCustomersByFlightIdAndFlightDate(@Param("flightId") int flightId,
             @Param("flightDate") Date flightDate);
}
