import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-get-employee',
  templateUrl: './get-employee.component.html',
  styleUrl: './get-employee.component.css'
})
export class GetEmployeeComponent implements OnInit {

  empid: number=0;
  employee: Employee

  constructor(private employeeService: EmployeeService,
    private route:ActivatedRoute){
      this.employee = new Employee;
    }

  ngOnInit(): void {
    this.empid= this.route.snapshot.params['empid'];
    this.employee = new Employee();
    this.employeeService.getEmployeeById(this.empid).subscribe(data =>{
      this.employee= data;
    })
  }

}
