import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrl: './employee-list.component.css'
})
export class EmployeeListComponent implements OnInit {

  empid:number=0;
  employees: Employee[];

  constructor(private employeeService: EmployeeService,
    private router: Router){
    this.employees=[];
  }

  ngOnInit(): void {
    
    this.getEmployees();
    
  }

  private getEmployees(){
    this.employeeService.getEmployeesList().subscribe(data =>{
      this.employees = data;
    });
  }

  updateEmployee(empid: number){
    this.router.navigate(['update-employee' ,empid]);
  }

 deleteEmployee(empid: number){
  this.employeeService.deleteEmployee(empid).subscribe(data => {
    console.log(data);
    this.getEmployees();
    // this.router.navigate(['employees']);

  })
 }
 getEmployee(empid: number){
  this.router.navigate(['getEmployee' ,empid]);
}

}
