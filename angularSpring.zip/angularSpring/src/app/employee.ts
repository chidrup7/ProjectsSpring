export class Employee {
    empid: number;
    firstName: string;
    lastName: string;
    email: string;

    constructor(){
        this.empid=0;
        this.firstName="";
        this.lastName="";
        this.email="";
    }
    
}
