import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrl: './update-employee.component.css'
})
export class UpdateEmployeeComponent implements OnInit {

  empid: number=0;
  employee: Employee = new Employee();
  constructor(private employeeService: EmployeeService,
    private route: ActivatedRoute, private router:Router){

  }

  ngOnInit(): void {
    this.empid = this.route.snapshot.params['empid'];
    this.employeeService.getEmployeeById(this.empid).subscribe(data=>{
      this.employee=data;
    });
  }

  onSubmit(){
    console.log("updated")
    this.employeeService.updateEmployee(this.empid, this.employee).subscribe(data=>{
      this.goToEmployee(); 
    })
  }

  goToEmployee(){
    this.router.navigate(['/employees']);
  }

}
